<?php

class Role 
{
	var $packet = null;
	var $version = null;
	var $roleId = null;
	var $roleName = null;
	var $roleRace = null;
	var $roleClass = null;
	var $roleGender = null;
	var $roleCustomData = null;
	var $roleConfigData = null;
	var $roleCustomStamp = null;
	var $roleStatus = null;
	var $roleDelTime = null;
	var $roleCreateTime = null;
	var $roleLastLogin = null;
	var $roleForbidData = null;
	var $roleHelpStates = null;
	var $spouse = null;
	var $userid = null;
	var $reserved3 = null;
	var $version2 = null;
	var $level = null;
	var $cultivation = null;
	var $experience = null;
	var $spirit = null;
	var $points = null;
	var $health = null;
	var $mana = null;
	var $posx = null;
	var $posy = null;
	var $posz = null;
	var $worldtag = null;
	var $invaderState = null;
	var $invaderTime = null;
	var $pariahTime = null;
	var $reputation = null;
	var $customStatus = null;
	var $filterData = null;
	var $characterMode = null;
	var $instanceKeyList = null;
	var $dbltimeExpire = null;
	var $dbltimeMode = null;
	var $dbltimeBegin = null;
	var $dbltimeUsed = null;
	var $dbltimeMax = null;
	var $timeUsed = null;
	var $dbltimeData = null;
	var $storesize = null;
	var $petCorral = null;
	var $stamina = null;
	var $intelligence = null;
	var $strong = null;
	var $agility = null;
	var $hp = null;
	var $mp = null;
	var $unk1 = null;
	var $attackRate = null;
	var $minPhysAtt = null;
	var $maxPhysAtt = null;
	var $unk2 = null;
	var $minMaxAttMagic = null;
	var $minMagAtt = null;
	var $maxMagAtt = null;
	var $unk3 = null;
	var $ci = null;
	var $varData = null;
	var $skills = null;
	var $storePass = null;
	var $wayPoints = null;
	var $coolingTime = null;
	var $npcrelation = null;
	var $multiexp = null;
	var $storagetask = null;
	var $factioncontrib = null;
	var $forceData = null;
	var $onlineAward = null;
	var $profitData = null;
	var $countryData = null;
	var $reserved22 = null;
	var $reserved33 = null;
	var $reserved44 = null;
	var $reserved55 = null;
	var $pocketCapacity = null;
	var $pocketTimestamp = null;
	var $pocketMoney = null;
	var $rolePocket = null;
	var $pocketReserved1 = null;
	var $pocketReserved2 = null;
	var $roleInventory = null;
	var $storeCapacity = null;
	var $storeMoney = null;
	var $roleStore = null;
	var $storeSize1 = null;
	var $storeSize2 = null;
	var $store1 = null;
	var $store2 = null;
	var $storeReserved = null;
	var $taskData = null;
	var $taskComplete = null;
	var $taskFinishTime = null;
	var $taskInventory = null;
	
	function __construct($roleid, $multiple = false)
	{
	/*
		if (isset( Yii::app( )->params->license_key )) 
		{
			$license_key = str_replace('-', '', Yii::app( )->params->license_key);
			$checkLicense1 = hash('sha256', base64_encode($_SERVER['SERVER_ADDR']) . 'perfect world' . 'fucking cheaters');
			
			if ($license_key != $checkLicense1)
			{
				exit('wrong license key');
			}
		}
		else
		{
			exit('wrong license key');
		}
	*/
		$this->Role($roleid, $multiple);
	}
	
	function parse($role)
	{
		$role = substr($role, 4);
		$length = 2 + hexdec(substr($role, 0, 2)) * 2;
		$length2 = 4 + 2 * (hexdec(substr($role, 0, 4)) - 32768);
		
		if ($length == strlen($role))
		{
			$role = substr($role, 2);
		}
		else
		{
			if ($length2 == strlen($role))
			{
				$role = substr($role, 4);
			}
			else
			{
				$role = substr($role, 8);
			}
		}
		
		$role = substr($role, 16);
		$this->version = hexdec(substr($role, 0, 2));
		$role = substr($role, 2);
		$this->roleId = hexdec(substr($role, 0, 8));
		$role = substr($role, 8);
		$lengthName = hexdec(substr($role, 0, 2)) * 2;
		$role = substr($role, 2);
		$this->roleName = iconv('UTF-16LE', 'UTF-8', Controller::hextostr(substr($role, 0, $lengthName)));
		$role = substr($role, $lengthName);
		$this->roleRace = hexdec(substr($role, 0, 8));
		$role = substr($role, 8);
		$this->roleClass = hexdec(substr($role, 0, 8));
		$role = substr($role, 8);
		$this->roleGender = hexdec(substr($role, 0, 2));
		$role = substr($role, 2);
		$lengthCustomData = hexdec(substr($role, 0, 2));
		
		if ($lengthCustomData < 64) 
		{
			$lengthCustomData = $lengthCustomData * 2;
			$role = substr($role, 2);
		}
		else
		{
			$lengthCustomData = 2 * (hexdec(substr($role, 0, 4)) - 32768);
			$role = substr($role, 4);
		}
		
		$this->roleCustomData = substr($role, 0, $lengthCustomData);
		$role = substr($role, $lengthCustomData);
		$lengthConfigData = hexdec(substr($role, 0, 2));
		
		if ($lengthConfigData < 64)
		{
			$lengthConfigData = $lengthConfigData * 2;
			$role = substr($role, 2);
		}
		else
		{
			$lengthConfigData = 2 * (hexdec(substr($role, 0, 4)) - 32768);
			$role = substr($role, 4);
		}
		
		$this->roleConfigData = substr($role, 0, $lengthConfigData);
		$role = substr($role, $lengthConfigData);
		$this->roleCustomStamp = hexdec(substr($role, 0, 8));
		$role = substr($role, 8);
		$this->roleStatus = hexdec(substr($role, 0, 2));
		$role = substr($role, 2);
		$this->roleDelTime = hexdec(substr($role, 0, 8));
		$role = substr($role, 8);
		$this->roleCreateTime = hexdec(substr($role, 0, 8));
		$role = substr($role, 8);
		$this->roleLastLogin = hexdec(substr($role, 0, 8));
		$role = substr($role, 8);
		$roleForbid = hexdec(substr($role, 0, 2));
		$role = substr($role, 2);
		
		if ($roleForbid != '0')
		{
			$i = 12;
			
			while ($i < $roleForbid)
			{
				$roleForbidData[$i]['type'] = substr($role, 0, 2);
				$role = substr($role, 2);
				$roleForbidData[$i]['time'] = hexdec(substr($role, 0, 8));
				$role = substr($role, 8);
				$roleForbidData[$i]['date'] = hexdec(substr($role, 0, 8));
				$role = substr($role, 8);
				$lengthWhy = hexdec(substr($role, 0, 2));
				
				if ($lengthWhy < 128) 
				{
					$lengthWhy = $lengthWhy * 2;
					$role = substr($role, 2);
					$roleForbidData[$i]['reason'] = iconv('UTF-16LE', 'UTF-8', Controller::hextostr(substr($role, 0, $lengthWhy)));
					$role = substr($role, $lengthWhy);
				}
				else 
				{
					$lengthWhy = 2 * (hexdec(substr($role, 0, 4)) - 32768);
					$role = substr($role, 4);
					$roleForbidData[$i]['reason'] = iconv('UTF-16LE', 'UTF-8', Controller::hextostr(substr($role, 0, $lengthWhy)));
					$role = substr($role, $lengthWhy);
				}
				
				++$i;
			}
			
			$this->roleForbidData = $roleForbidData;
		}
		
		$lengthHelpStates = hexdec(substr($role, 0, 2));
		
		if ($lengthHelpStates < 128)
		{
			$lengthHelpStates = $lengthHelpStates * 2;
			$role = substr($role, 2);
		}
		else 
		{
			$lengthHelpStates = 2 * (hexdec(substr($role, 0, 4)) - 32768);
			$role = substr($role, 4);
		}
		
		$this->roleHelpStates = substr($role, 0, $lengthHelpStates);
		$role = substr($role, $lengthHelpStates);
		$this->spouse = hexdec(substr($role, 0, 8));
		$role = substr($role, 8);
		$this->userid = hexdec(substr($role, 0, 8));
		$role = substr($role, 8);
		$this->reserved3 = hexdec(substr($role, 0, 8));
		$role = substr($role, 8);
		$this->version2 = hexdec(substr($role, 0, 2));
		$role = substr($role, 2);
		$this->level = hexdec(substr($role, 0, 8));
		$role = substr($role, 8);
		$this->cultivation = hexdec(substr($role, 0, 8));
		$role = substr($role, 8);
		$this->experience = hexdec(substr($role, 0, 8));
		$role = substr($role, 8);
		$this->spirit = hexdec(substr($role, 0, 8));
		$role = substr($role, 8);
		$this->points = hexdec(substr($role, 0, 8));
		$role = substr($role, 8);
		$this->health = hexdec(substr($role, 0, 8));
		$role = substr($role, 8);
		$this->mana = hexdec(substr($role, 0, 8));
		$role = substr($role, 8);
		$tposx = unpack('f', strrev(pack('H*', substr($role, 0, 8))));
		$this->posx = $tposx['1'];
		$role = substr($role, 8);
		$tposy = unpack('f', strrev(pack('H*', substr($role, 0, 8))));
		$this->posy = $tposy['1'];
		$role = substr($role, 8);
		$tposz = unpack('f', strrev(pack('H*', substr($role, 0, 8))));
		$this->posz = $tposz['1'];
		$role = substr($role, 8);
		$this->worldtag = hexdec(substr($role, 0, 8));
		$role = substr($role, 8);
		$this->invaderState = hexdec(substr($role, 0, 8));
		$role = substr($role, 8);
		$this->invaderTime = hexdec(substr($role, 0, 8));
		$role = substr($role, 8);
		$this->pariahTime = hexdec(substr($role, 0, 8));
		$role = substr($role, 8);
		$this->reputation = hexdec(substr($role, 0, 8));
		$role = substr($role, 8);
		$lengthCustomStatus = hexdec(substr($role, 0, 2));
		
		if ($lengthCustomStatus < 128)
		{
			$lengthCustomStatus = $lengthCustomStatus * 2;
			$role = substr($role, 2);
		}
		else
		{
			$lengthCustomStatus = 2 * (hexdec(substr($role, 0, 4)) - 32768);
			$role = substr($role, 4);
		}
		
		$this->customStatus = substr($role, 0, $lengthCustomStatus);
		$role = substr($role, $lengthCustomStatus);
		$lengthFilterData = hexdec(substr($role, 0, 2));
		
		if ($lengthFilterData < 128)
		{
			$lengthFilterData = $lengthFilterData * 2;
			$role = substr($role, 2);
		}
		else
		{
			$lengthFilterData = 2 * (hexdec(substr($role, 0, 4)) - 32768);
			$role = substr($role, 4);
		}
		
		$this->filterData = substr($role, 0, $lengthFilterData);
		$role = substr($role, $lengthFilterData);
		$lengthCharacterMode = hexdec(substr($role, 0, 2));
		
		if ($lengthCharacterMode < 128) 
		{
			$lengthCharacterMode = $lengthCharacterMode * 2;
			$role = substr($role, 2);
		}
		else 
		{
			$lengthCharacterMode = 2 * (hexdec(substr($role, 0, 4)) - 32768);
			$role = substr($role, 4);
		}
		
		$this->characterMode = substr($role, 0, $lengthCharacterMode);
		$role = substr($role, $lengthCharacterMode);
		$lengthInstanceKeyList = hexdec(substr($role, 0, 2));
		
		if ($lengthInstanceKeyList < 128) 
		{
			$lengthInstanceKeyList = $lengthInstanceKeyList * 2;
			$role = substr($role, 2);
		}
		else 
		{
			$lengthInstanceKeyList = 2 * (hexdec(substr($role, 0, 4)) - 32768);
			$role = substr($role, 4);
		}
		
		$this->instanceKeyList = substr($role, 0, $lengthInstanceKeyList);
		$role = substr($role, $lengthInstanceKeyList);
		$this->dbltimeExpire = hexdec(substr($role, 0, 8));
		$role = substr($role, 8);
		$this->dbltimeMode = hexdec(substr($role, 0, 8));
		$role = substr($role, 8);
		$this->dbltimeBegin = hexdec(substr($role, 0, 8));
		$role = substr($role, 8);
		$this->dbltimeUsed = hexdec(substr($role, 0, 8));
		$role = substr($role, 8);
		$this->dbltimeMax = hexdec(substr($role, 0, 8));
		$role = substr($role, 8);
		$this->timeUsed = hexdec(substr($role, 0, 8));
		$role = substr($role, 8);
		$lengthTimeData = hexdec(substr($role, 0, 2));
		
		if ($lengthTimeData < 128) 
		{
			$lengthTimeData = $lengthTimeData * 2;
			$role = substr($role, 2);
		}
		else 
		{
			$lengthTimeData = 2 * (hexdec(substr($role, 0, 4)) - 32768);
			$role = substr($role, 4);
		}
		
		$this->dbltimeData = substr($role, 0, $lengthTimeData);
		$role = substr($role, $lengthTimeData);
		$this->storesize = substr($role, 0, 4);
		$role = substr($role, 4);
		$lengthPetCorral = hexdec(substr($role, 0, 2));
		
		if ($lengthPetCorral < 128) 
		{
			$lengthPetCorral = $lengthPetCorral * 2;
			$role = substr($role, 2);
		}
		else 
		{
			$lengthPetCorral = 2 * (hexdec(substr($role, 0, 4)) - 32768);
			$role = substr($role, 4);
		}
		
		$this->petCorral = substr($role, 0, $lengthPetCorral);
		$role = substr($role, $lengthPetCorral);
		$role = substr($role, 4);
		$this->stamina = Controller::suckhextoint(substr($role, 0, 8));
		$role = substr($role, 8);
		$this->intelligence = Controller::suckhextoint(substr($role, 0, 8));
		$role = substr($role, 8);
		$this->strong = Controller::suckhextoint(substr($role, 0, 8));
		$role = substr($role, 8);
		$this->agility = Controller::suckhextoint(substr($role, 0, 8));
		$role = substr($role, 8);
		$this->hp = Controller::suckhextoint(substr($role, 0, 8));
		$role = substr($role, 8);
		$this->mp = Controller::suckhextoint(substr($role, 0, 8));
		$role = substr($role, 8);
		$this->unk1 = substr($role, 0, 48);
		$role = substr($role, 48);
		$this->attackRate = Controller::suckhextoint(substr($role, 0, 8));
		$role = substr($role, 8);
		$this->minPhysAtt = Controller::suckhextoint(substr($role, 0, 8));
		$role = substr($role, 8);
		$this->maxPhysAtt = Controller::suckhextoint(substr($role, 0, 8));
		$role = substr($role, 8);
		$this->unk2 = substr($role, 0, 16);
		$role = substr($role, 16);
		$this->minMaxAttMagic = substr($role, 0, 80);
		$role = substr($role, 80);
		$this->minMagAtt = Controller::suckhextoint(substr($role, 0, 8));
		$role = substr($role, 8);
		$this->maxMagAtt = Controller::suckhextoint(substr($role, 0, 8));
		$role = substr($role, 8);
		$this->unk3 = substr($role, 0, 56);
		$role = substr($role, 56);
		$this->ci = Controller::suckhextoint(substr($role, 0, 8));
		$role = substr($role, 8);
		$lengthVarData = hexdec(substr($role, 0, 2));
		
		if ($lengthVarData < 128)
		{
			$lengthVarData = $lengthVarData * 2;
			$role = substr($role, 2);
		}
		else 
		{
			$lengthVarData = 2 * (hexdec(substr($role, 0, 4)) - 32768);
			$role = substr($role, 4);
		}
		
		$this->varData = substr($role, 0, $lengthVarData);
		$role = substr($role, $lengthVarData);
		$lengthSkills = hexdec(substr($role, 0, 2));
		
		if ($lengthSkills < 128)
		{
			$lengthSkills = $lengthSkills * 2;
			$role = substr($role, 2);
		}
		else
		{
			$lengthSkills = 2 * (hexdec(substr($role, 0, 4)) - 32768);
			$role = substr($role, 4);
		}
		
		$skills = substr($role, 0, $lengthSkills);
		$role = substr($role, $lengthSkills);
		
		if ((isset($skills) && !empty($skills)))
		{
			$count = Controller::suckhextoint(substr($skills, 0, 8));
			$skills = substr($skills, 8);
		}
		else 
		{
			$count = '0';
		}
		
		if ($count != '0')
		{
			$i = 12;
			
			while ($i < $count)
			{
				$roleSkill[$i]['id'] = Controller::suckhextoint(substr($skills, 0, 8));
				$skills = substr($skills, 8)
				$roleSkill[$i]['progress'] = Controller::suckhextoint(substr($skills, 0, 8));
				$skills = substr($skills, 8)
				$roleSkill[$i]['level'] = Controller::suckhextoint(substr($skills, 0, 8));
				$skills = substr($skills, 8)
				++$i;
			}
			
			$this->skills = $roleSkill;
		}
		
		$lengthStorePass = hexdec(substr($role, 0, 2));
		
		if ($lengthStorePass < 128) 
		{
			$lengthStorePass = $lengthStorePass * 2;
			$role = substr($role, 2);
		}
		else 
		{
			$lengthStorePass = 2 * (hexdec(substr($role, 0, 4)) - 32768);
			$role = substr($role, 4);
		}
		
		$this->storePass = substr($role, 0, $lengthStorePass);
		$role = substr($role, $lengthStorePass);
		$lengthWayPoints = hexdec(substr($role, 0, 2));
		
		if ($lengthWayPoints < 128)
		{
			$lengthWayPoints = $lengthWayPoints * 2;
			$role = substr($role, 2);
		}
		else 
		{
			$lengthWayPoints = 2 * (hexdec(substr($role, 0, 4)) - 32768);
			$role = substr($role, 4);
		}
		
		$this->wayPoints = substr($role, 0, $lengthWayPoints);
		$role = substr($role, $lengthWayPoints);
		$lengthCoolingTime = hexdec(substr($role, 0, 2));
		
		if ($lengthCoolingTime < 128) 
		{
			$lengthCoolingTime = $lengthCoolingTime * 2;
			$role = substr($role, 2);
		}
		else 
		{
			$lengthCoolingTime = 2 * (hexdec(substr($role, 0, 4)) - 32768);
			$role = substr($role, 4);
		}
		
		$this->coolingTime = substr($role, 0, $lengthCoolingTime);
		$role = substr($role, $lengthCoolingTime);
		$lengthNpcRelation = hexdec(substr($role, 0, 2));
		
		if ($lengthNpcRelation < 128) 
		{
			$lengthNpcRelation = $lengthNpcRelation * 2;
			$role = substr($role, 2);
		}
		else
		{
			$lengthNpcRelation = 2 * (hexdec(substr($role, 0, 4)) - 32768);
			$role = substr($role, 4);
		}
		
		$this->npcrelation = substr($role, 0, $lengthNpcRelation);
		$role = substr($role, $lengthNpcRelation);
		$lengthMultiExp = hexdec(substr($role, 0, 2));
		
		if ($lengthMultiExp < 128)
		{
			$lengthMultiExp = $lengthMultiExp * 2;
			$role = substr($role, 2);
		}
		else
		{
			$lengthMultiExp = 2 * (hexdec(substr($role, 0, 4)) - 32768);
			$role = substr($role, 4);
		}
		
		$this->multiexp = substr($role, 0, $lengthMultiExp);
		$role = substr($role, $lengthMultiExp);
		$lengthStorageTask = hexdec(substr($role, 0, 2));
		
		if ($lengthStorageTask < 128)
		{
			$lengthStorageTask = $lengthStorageTask * 2;
			$role = substr($role, 2);
		}
		else
		{
			$lengthStorageTask = 2 * (hexdec(substr($role, 0, 4)) - 32768);
			$role = substr($role, 4);
		}
		
		$this->storagetask = substr($role, 0, $lengthStorageTask);
		$role = substr($role, $lengthStorageTask);
		$lengthFactionContrib = hexdec(substr($role, 0, 2));
		
		if ($lengthFactionContrib < 128) 
		{
			$lengthFactionContrib = $lengthFactionContrib * 2;
			$role = substr($role, 2);
		}
		else
		{
			$lengthFactionContrib = 2 * (hexdec(substr($role, 0, 4)) - 32768);
			$role = substr($role, 4);
		}
		
		$factionContrib = substr($role, 0, $lengthFactionContrib);
		$role = substr($role, $lengthFactionContrib);
		
		if (( isset($factionContrib ) && 0 < $lengthFactionContrib )) 
		{
			$factionDeposit = Controller::suckhextoint( substr($factionContrib, 0, 8 ));
			$factionFreeDeposit = Controller::suckhextoint( substr($factionContrib, 8, 16 ));
			$factionFeat = Controller::suckhextoint( substr($factionContrib, 16, 24 ));
			$this->factioncontrib = array( 'deposit' => $factionDeposit, 'freeDeposit' => $factionFreeDeposit, 'feat' => $factionFeat);
		}
		
		if (( ( Yii::app(  )->params->version == '1.4.5' || Yii::app(  )->params->version == '1.4.5.69' ) || Yii::app(  )->params->version == '1.4.6' )) 
		{
			$lengthForceData = hexdec(substr($role, 0, 2));
			
			if ($lengthForceData < 128) 
			{
				$lengthForceData = $lengthForceData * 2;
				$role = substr($role, 2);
			}
			else
			{
				$lengthForceData = 2 * (hexdec(substr($role, 0, 4)) - 32768);
				$role = substr($role, 4);
			}
			
			$this->forceData = substr($role, 0, $lengthForceData);
			$role = substr($role, $lengthForceData);
			
			if ((Yii::app( )->params->version == '1.4.5.69' || Yii::app( )->params->version == '1.4.6'))
			{
				$lengthOnlineAward = hexdec(substr($role, 0, 2));
				
				if ($lengthOnlineAward < 128)
				{
					$lengthOnlineAward = $lengthOnlineAward * 2;
					$role = substr($role, 2);
				}
				else
				{
					$lengthOnlineAward = 2 * (hexdec(substr($role, 0, 4)) - 32768);
					$role = substr($role, 4);
				}
				
				$this->onlineAward = substr($role, 0, $lengthOnlineAward);
				$role = substr($role, $lengthOnlineAward);
				$lengthProfitData = hexdec(substr($role, 0, 2));
				
				if ($lengthProfitData < 128)
				{
					$lengthProfitData = $lengthProfitData * 2;
					$role = substr($role, 2);
				}
				else
				{
					$lengthProfitData = 2 * (hexdec(substr($role, 0, 4)) - 32768);
					$role = substr($role, 4);
				}
				
				$this->profitData = substr($role, 0, $lengthProfitData);
				$role = substr($role, $lengthProfitData);
			}
			
			
			if (Yii::app(  )->params->version == '1.4.6')
			{
				$lengthCountryData = hexdec(substr($role, 0, 2));
				
				if ($lengthCountryData < 128)
				{
					$lengthCountryData = $lengthCountryData * 2;
					$role = substr($role, 2);
				}
				else 
				{
					$lengthCountryData = 2 * (hexdec(substr($role, 0, 4)) - 32768);
					$role = substr($role, 4);
				}
				
				$this->countryData = substr($role, 0, $lengthCountryData);
				$role = substr($role, $lengthCountryData);
			}
			else
			{
				$this->reserved22 = hexdec(substr($role, 0, 2));
				$role = substr($role, 2);
			}
			
			
			if (Yii::app( )->params->version == '1.4.5')
			{
				$this->reserved33 = hexdec( substr($role, 0, 4 ));
				$role = substr($role, 4);
			}
		}
		else
		{
			$this->reserved22 = hexdec(substr($role, 0, 8));
			$role = substr($role, 8);
			$this->reserved33 = hexdec(substr($role, 0, 8));
			$role = substr($role, 8);
		}
		
		$this->reserved44 = hexdec(substr($role, 0, 8));
		$role = substr($role, 8);
		
		if (((Yii::app( )->params->version == '1.4.5' || Yii::app( )->params->version == '1.4.5.69' ) || Yii::app( )->params->version == '1.4.6'))
		{
			$this->reserved55 = hexdec(substr($role, 0, 8));
			$role = substr($role, 8);
		}
		
		$this->pocketCapacity = hexdec(substr($role, 0, 8));
		$role = substr($role, 8);
		$this->pocketTimestamp = hexdec(substr($role, 0, 8));
		$role = substr($role, 8);
		$this->pocketMoney = hexdec(substr($role, 0, 8));
		$role = substr($role, 8);
		$count = hexdec(substr($role, 0, 2));
		$role = substr($role, 2);
		
		if ($count != '0')
		{
			$i = 12;
			
			while ($i < $count)
			{
				$roleItem[$i]['id'] = hexdec(substr($role, 0, 8));
				$role = substr($role, 8);
				$roleItem[$i]['pos'] = hexdec(substr($role, 0, 8));
				$role = substr($role, 8);
				$roleItem[$i]['count'] = hexdec(substr($role, 0, 8));
				$role = substr($role, 8);
				$roleItem[$i]['maxcount'] = hexdec(substr($role, 0, 8));
				$role = substr($role, 8);
				$lengthOctet = hexdec(substr($role, 0, 2));
				
				if ($lengthOctet < 128)
				{
					$role = substr($role, 2);
					$lengthOctet = $lengthOctet * 2;
				}
				else 
				{
					$lengthOctet = 2 * (hexdec(substr($role, 0, 4)) - 32768);
					$role = substr($role, 4);
				}
				
				$roleItem[$i]['octet'] = substr($role, 0, $lengthOctet);
				$role = substr($role, $lengthOctet);
				$roleItem[$i]['proctype'] = hexdec(substr($role, 0, 8));
				$role = substr($role, 8);
				$roleItem[$i]['data'] = hexdec(substr($role, 0, 8));
				$role = substr($role, 8);
				$roleItem[$i]['guid1'] = hexdec(substr($role, 0, 8));
				$role = substr($role, 8);
				$roleItem[$i]['guid2'] = hexdec(substr($role, 0, 8));
				$role = substr($role, 8);
				$roleItem[$i]['mask'] = hexdec(substr($role, 0, 8));
				$role = substr($role, 8);
				++$i;
			}
			
			$this->rolePocket = $roleItem;
		}
		
		$this->pocketReserved1 = hexdec(substr($role, 0, 8));
		$role = substr($role, 8);
		$this->pocketReserved2 = hexdec(substr($role, 0, 8));
		$role = substr($role, 8);
		$count = hexdec(substr($role, 0, 2));
		$role = substr($role, 2);
		
		if ($count != '0')
		{
			$i = 12;
			
			while ($i < $count)
			{
				$roleItem2[$i]['id'] = hexdec(substr($role, 0, 8));
				$role = substr($role, 8);
				$roleItem2[$i]['pos'] = hexdec(substr($role, 0, 8));
				$role = substr($role, 8);
				$roleItem2[$i]['count'] = hexdec(substr($role, 0, 8));
				$role = substr($role, 8);
				$roleItem2[$i]['maxcount'] = hexdec(substr($role, 0, 8));
				$role = substr($role, 8);
				$lengthOctet = hexdec(substr($role, 0, 2));
				
				if ($lengthOctet < 128) 
				{
					$role = substr($role, 2);
					$lengthOctet = $lengthOctet * 2;
				}
				else
				{
					$lengthOctet = 2 * (hexdec(substr($role, 0, 4)) - 32768);
					$role = substr($role, 4);
				}
				
				$roleItem2[$i]['octet'] = substr($role, 0, $lengthOctet);
				$role = substr($role, $lengthOctet);
				$roleItem2[$i]['proctype'] = hexdec(substr($role, 0, 8));
				$role = substr($role, 8);
				$roleItem2[$i]['data'] = hexdec(substr($role, 0, 8));
				$role = substr($role, 8);
				$roleItem2[$i]['guid1'] = hexdec(substr($role, 0, 8));
				$role = substr($role, 8);
				$roleItem2[$i]['guid2'] = hexdec(substr($role, 0, 8));
				$role = substr($role, 8);
				$roleItem2[$i]['mask'] = hexdec(substr($role, 0, 8));
				$role = substr($role, 8);
				++$i;
			}
			
			$this->roleInventory = $roleItem2;
		}
		
		$this->storeCapacity = hexdec(substr($role, 0, 8));
		$role = substr($role, 8);
		$this->storeMoney = hexdec(substr($role, 0, 8));
		$role = substr($role, 8);
		$count = hexdec(substr($role, 0, 2));
		$count = hexdec(substr($role, 0, 2));
		
		if ($count < 128)
		{
			$role = substr($role, 2);
		}
		else
		{
			$count = hexdec(substr($role, 0, 4)) - 32768;
			$role = substr($role, 4);
		}
		
		
		if ($count != '0') 
		{
			$i = 12;
			
			while ($i < $count)
			{
				$roleItem3[$i]['id'] = hexdec(substr($role, 0, 8));
				$role = substr($role, 8);
				$roleItem3[$i]['pos'] = hexdec(substr($role, 0, 8));
				$role = substr($role, 8);
				$roleItem3[$i]['count'] = hexdec(substr($role, 0, 8));
				$role = substr($role, 8);
				$roleItem3[$i]['maxcount'] = hexdec(substr($role, 0, 8));
				$role = substr($role, 8);
				$lengthOctet = hexdec(substr($role, 0, 2));
				
				if ($lengthOctet < 128) 
				{
					$role = substr($role, 2);
					$lengthOctet = $lengthOctet * 2;
				}
				else 
				{
					$lengthOctet = 2 * (hexdec(substr($role, 0, 4)) - 32768);
					$role = substr($role, 4);
				}
				
				$roleItem3[$i]['octet'] = substr($role, 0, $lengthOctet);
				$role = substr($role, $lengthOctet);
				$roleItem3[$i]['proctype'] = hexdec(substr($role, 0, 8));
				$role = substr($role, 8);
				$roleItem3[$i]['data'] = hexdec(substr($role, 0, 8));
				$role = substr($role, 8);
				$roleItem3[$i]['guid1'] = hexdec(substr($role, 0, 8));
				$role = substr($role, 8);
				$roleItem3[$i]['guid2'] = hexdec(substr($role, 0, 8));
				$role = substr($role, 8);
				$roleItem3[$i]['mask'] = hexdec(substr($role, 0, 8));
				$role = substr($role, 8);
				++$i;
			}
			
			$this->roleStore = $roleItem3;
		}
		
		$this->storeSize1 = hexdec(substr($role, 0, 2));
		$role = substr($role, 2);
		$this->storeSize2 = hexdec(substr($role, 0, 2));
		$role = substr($role, 2);
		$count = hexdec(substr($role, 0, 2));
		$role = substr($role, 2);
		
		if ($count != '0')
		{
			$i = 12;
			
			while ($i < $count)
			{
				$roleItem5[$i]['id'] = hexdec(substr($role, 0, 8));
				$role = substr($role, 8);
				$roleItem5[$i]['pos'] = hexdec(substr($role, 0, 8));
				$role = substr($role, 8);
				$roleItem5[$i]['count'] = hexdec(substr($role, 0, 8));
				$role = substr($role, 8);
				$roleItem5[$i]['maxcount'] = hexdec(substr($role, 0, 8));
				$role = substr($role, 8);
				$lengthOctet = hexdec(substr($role, 0, 2));
				
				if ($lengthOctet < 128)
				{
					$role = substr($role, 2);
					$lengthOctet = $lengthOctet * 2;
				}
				else
				{
					$lengthOctet = 2 * (hexdec(substr($role, 0, 4)) - 32768);
					$role = substr($role, 4);
				}
				
				$roleItem5[$i]['octet'] = substr($role, 0, $lengthOctet);
				$role = substr($role, $lengthOctet);
				$roleItem5[$i]['proctype'] = hexdec(substr($role, 0, 8));
				$role = substr($role, 8);
				$roleItem5[$i]['data'] = hexdec(substr($role, 0, 8));
				$role = substr($role, 8);
				$roleItem5[$i]['guid1'] = hexdec(substr($role, 0, 8));
				$role = substr($role, 8);
				$roleItem5[$i]['guid2'] = hexdec(substr($role, 0, 8));
				$role = substr($role, 8);
				$roleItem5[$i]['mask'] = hexdec(substr($role, 0, 8));
				$role = substr($role, 8);
				++$i;
			}
			
			$this->store1 = $roleItem5;
		}
		
		$count = hexdec(substr($role, 0, 2));
		
		if ($count < 128)
		{
			$role = substr($role, 2);
		}
		else
		{
			$count = hexdec( substr($role, 0, 4 ) ) - 32768;
			$role = substr($role, 4);
		}
		
		
		if ($count != '0') 
		{
			$i = 12;
			
			while ($i < $count) 
			{
				$roleItem6[$i]['id'] = hexdec(substr($role, 0, 8));
				$role = substr($role, 8);
				$roleItem6[$i]['pos'] = hexdec(substr($role, 0, 8));
				$role = substr($role, 8);
				$roleItem6[$i]['count'] = hexdec(substr($role, 0, 8));
				$role = substr($role, 8);
				$roleItem6[$i]['maxcount'] = hexdec(substr($role, 0, 8));
				$role = substr($role, 8);
				$lengthOctet = hexdec(substr($role, 0, 2));
				
				if ($lengthOctet < 128) 
				{
					$role = substr($role, 2);
					$lengthOctet = $lengthOctet * 2;
				}
				else
				{
					$lengthOctet = 2 * (hexdec(substr($role, 0, 4)) - 32768);
					$role = substr($role, 4);
				}
				
				$roleItem6[$i]['octet'] = substr($role, 0, $lengthOctet);
				$role = substr($role, $lengthOctet);
				$roleItem6[$i]['proctype'] = hexdec(substr($role, 0, 8));
				$role = substr($role, 8);
				$roleItem6[$i]['data'] = hexdec(substr($role, 0, 8));
				$role = substr($role, 8);
				$roleItem6[$i]['guid1'] = hexdec(substr($role, 0, 8));
				$role = substr($role, 8);
				$roleItem6[$i]['guid2'] = hexdec(substr($role, 0, 8));
				$role = substr($role, 8);
				$roleItem6[$i]['mask'] = hexdec(substr($role, 0, 8));
				$role = substr($role, 8);
				++$i;
			}
			
			$this->store2 = $roleItem6;
		}
		
		$this->storeReserved = hexdec(substr($role, 0, 8));
		$role = substr($role, 8);
		$lengthTaskData = hexdec(substr($role, 0, 2));
		
		if ($lengthTaskData < 128) 
		{
			$role = substr($role, 2);
			$lengthTaskData = $lengthTaskData * 2;
		}
		else
		{
			$lengthTaskData = 2 * (hexdec(substr($role, 0, 4)) - 32768);
			$role = substr($role, 4);
		}
		
		$this->taskData = substr($role, 0, $lengthTaskData);
		$role = substr($role, $lengthTaskData);
		$lengthTaskComplete = hexdec(substr($role, 0, 2));
		
		if ($lengthTaskComplete < 128) 
		{
			$role = substr($role, 2);
			$lengthTaskComplete = $lengthTaskComplete * 2;
		}
		else
		{
			$lengthTaskComplete = 2 * (hexdec(substr($role, 0, 4)) - 32768);
			$role = substr($role, 4);
		}
		
		$this->taskComplete = substr($role, 0, $lengthTaskComplete);
		$role = substr($role, $lengthTaskComplete);
		$lengthTaskFinishTime = hexdec(substr($role, 0, 2));
		
		if ($lengthTaskFinishTime < 128) 
		{
			$role = substr($role, 2);
			$lengthTaskFinishTime = $lengthTaskFinishTime * 2;
		}
		else
		{
			$lengthTaskFinishTime = 2 * (hexdec(substr($role, 0, 4)) - 32768);
			$role = substr($role, 4);
		}
		
		$this->taskFinishTime = substr($role, 0, $lengthTaskFinishTime);
		$role = substr($role, $lengthTaskFinishTime);
		$count = hexdec(substr($role, 0, 2));
		$role = substr($role, 2);
		
		if ($count != '0') 
		{
			$i = 12;
			
			while ($i < $count) 
			{
				$roleItem4[$i]['id'] = hexdec(substr($role, 0, 8));
				$role = substr($role, 8);
				$roleItem4[$i]['pos'] = hexdec(substr($role, 0, 8));
				$role = substr($role, 8);
				$roleItem4[$i]['count'] = hexdec(substr($role, 0, 8));
				$role = substr($role, 8);
				$roleItem4[$i]['maxcount'] = hexdec(substr($role, 0, 8));
				$role = substr($role, 8);
				$lengthOctet = hexdec(substr($role, 0, 2));
				
				if ($lengthOctet < 128)
				{
					$role = substr($role, 2);
					$lengthOctet = $lengthOctet * 2;
				}
				else
				{
					$lengthOctet = 2 * (hexdec(substr($role, 0, 4)) - 32768);
					$role = substr($role, 4);
				}
				
				$roleItem4[$i]['octet'] = substr($role, 0, $lengthOctet);
				$role = substr($role, $lengthOctet);
				$roleItem4[$i]['proctype'] = hexdec(substr($role, 0, 8));
				$role = substr($role, 8);
				$roleItem4[$i]['data'] = hexdec(substr($role, 0, 8));
				$role = substr($role, 8);
				$roleItem4[$i]['guid1'] = hexdec(substr($role, 0, 8));
				$role = substr($role, 8);
				$roleItem4[$i]['guid2'] = hexdec(substr($role, 0, 8));
				$role = substr($role, 8);
				$roleItem4[$i]['mask'] = hexdec(substr($role, 0, 8));
				$role = substr($role, 8);
				++$i;
			}
			
			$this->taskInventory = $roleItem4;
		}
		
	}
	
	function save()
	{
		$returnData = Controller::cuint($this->version);
		$returnData .= Controller::pack8int($this->roleId);
		$this->roleName = iconv( 'UTF-8', 'UTF-16LE', $this->roleName);
		$returnData .= Controller::cuint( strlen($this->roleName ));
		$returnData .= $this->roleName;
		$returnData .= Controller::pack8int($this->roleRace);
		$returnData .= Controller::pack8int($this->roleClass);
		$returnData .= Controller::cuint($this->roleGender);
		$returnData .= Controller::cuint( strlen($this->roleCustomData) / 2);
		$returnData .= pack('H*', $this->roleCustomData);
		$returnData .= Controller::cuint( strlen($this->roleConfigData) / 2);
		$returnData .= pack('H*', $this->roleConfigData);
		$returnData .= Controller::pack8int($this->roleCustomStamp);
		$returnData .= Controller::cuint($this->roleStatus);
		$returnData .= Controller::pack8int($this->roleDelTime);
		$returnData .= Controller::pack8int($this->roleCreateTime);
		$returnData .= Controller::pack8int($this->roleLastLogin);
		
		if ($this->roleForbidData == 0)
		{
			$returnData .= pack('H*', '00');
		}
		else
		{
			$count = count($this->roleForbidData);
			$returnData .= Controller::cuint($count);
			$roleForbidData = $this->roleForbidData;
			$i = 12;
			
			while ($i < $count)
			{
				$returnData .= pack('H*', $roleForbidData[$i]['type']);
				$returnData .= Controller::pack8int($roleForbidData[$i]['time']);
				$returnData .= Controller::pack8int($roleForbidData[$i]['date']);
				$roleReason = $roleForbidData[$i]['reason'];
				$roleReason = iconv( 'UTF-8', 'UTF-16LE', $roleReason);
				$returnData .= Controller::cuintoctet(strlen($roleReason ));
				$returnData .= $roleReason;
				++$i;
			}
		}
		
		$returnData .= Controller::cuint(strlen($this->roleHelpStates ) / 2);
		$returnData .= pack('H*', $this->roleHelpStates);
		$returnData .= Controller::pack8int($this->spouse);
		$returnData .= Controller::pack8int($this->userid);
		$returnData .= Controller::pack8int($this->reserved3);
		$returnData .= Controller::cuint($this->version2);
		$returnData .= Controller::pack8int($this->level);
		$returnData .= Controller::pack8int($this->cultivation);
		$returnData .= Controller::pack8int($this->experience);
		$returnData .= Controller::pack8int($this->spirit);
		$returnData .= Controller::pack8int($this->points);
		$returnData .= Controller::pack8int($this->health);
		$returnData .= Controller::pack8int($this->mana);
		$returnData .= strrev(pack('f', $this->posx));
		$returnData .= strrev(pack('f', $this->posy));
		$returnData .= strrev(pack('f', $this->posz));
		$returnData .= Controller::pack8int($this->worldtag);
		$returnData .= Controller::pack8int($this->invaderState);
		$returnData .= Controller::pack8int($this->invaderTime);
		$returnData .= Controller::pack8int($this->pariahTime);
		$returnData .= Controller::pack8int($this->reputation);
		$returnData .= Controller::cuintoctet(strlen($this->customStatus ) / 2);
		$returnData .= pack('H*', $this->customStatus);
		$returnData .= Controller::cuintoctet(strlen($this->filterData ) / 2);
		$returnData .= pack('H*', $this->filterData);
		$returnData .= Controller::cuintoctet(strlen($this->characterMode ) / 2);
		$returnData .= pack('H*', $this->characterMode);
		$returnData .= Controller::cuintoctet(strlen($this->instanceKeyList ) / 2);
		$returnData .= pack('H*', $this->instanceKeyList);
		$returnData .= Controller::pack8int($this->dbltimeExpire);
		$returnData .= Controller::pack8int($this->dbltimeMode);
		$returnData .= Controller::pack8int($this->dbltimeBegin);
		$returnData .= Controller::pack8int($this->dbltimeUsed);
		$returnData .= Controller::pack8int($this->dbltimeMax);
		$returnData .= Controller::pack8int($this->timeUsed);
		$returnData .= Controller::cuintoctet(strlen($this->dbltimeData) / 2);
		$returnData .= pack('H*', $this->dbltimeData);
		$returnData .= pack('H*', $this->storesize);
		$returnData .= Controller::cuintoctet(strlen($this->petCorral ) / 2);
		$returnData .= pack('H*', $this->petCorral);
		$returnData .= pack('H*', '8094');
		$returnData .= strrev(Controller::pack8int($this->stamina));
		$returnData .= strrev(Controller::pack8int($this->intelligence));
		$returnData .= strrev(Controller::pack8int($this->strong));
		$returnData .= strrev(Controller::pack8int($this->agility));
		$returnData .= strrev(Controller::pack8int($this->hp));
		$returnData .= strrev(Controller::pack8int($this->mp));
		$returnData .= pack('H*', $this->unk1);
		$returnData .= strrev(Controller::pack8int($this->attackRate));
		$returnData .= strrev(Controller::pack8int($this->minPhysAtt));
		$returnData .= strrev(Controller::pack8int($this->maxPhysAtt));
		$returnData .= pack('H*', $this->unk2);
		$returnData .= pack('H*', $this->minMaxAttMagic);
		$returnData .= strrev(Controller::pack8int($this->minMagAtt));
		$returnData .= strrev(Controller::pack8int($this->maxMagAtt));
		$returnData .= pack('H*', $this->unk3);
		$returnData .= strrev(Controller::pack8int($this->ci));
		$returnData .= Controller::cuintoctet(strlen($this->varData) / 2);
		$returnData .= pack('H*', $this->varData);
		$roleSkill = $this->skills;
		$countSkills = count($roleSkill);
		$skillOctet = Controller::inttosuckhex($countSkills);
		$i = 12;
		
		while ($i < $countSkills)
		{
			$skillOctet .= Controller::inttosuckhex($roleSkill[$i]['id']);
			$skillOctet .= Controller::inttosuckhex($roleSkill[$i]['progress']);
			$skillOctet .= Controller::inttosuckhex($roleSkill[$i]['level']);
			++$i;
		}
		
		$returnData .= Controller::cuintoctet(strlen($skillOctet) / 2);
		$returnData .= pack('H*', $skillOctet);
		$returnData .= Controller::cuintoctet(strlen($this->storePass) / 2);
		$returnData .= pack('H*', $this->storePass);
		$returnData .= Controller::cuintoctet(strlen($this->wayPoints) / 2);
		$returnData .= pack('H*', $this->wayPoints);
		$returnData .= Controller::cuintoctet(strlen($this->coolingTime) / 2);
		$returnData .= pack('H*', $this->coolingTime);
		$returnData .= Controller::cuintoctet(strlen($this->npcrelation) / 2);
		$returnData .= pack('H*', $this->npcrelation);
		$returnData .= Controller::cuintoctet(strlen($this->multiexp) / 2);
		$returnData .= pack('H*', $this->multiexp);
		$returnData .= Controller::cuintoctet(strlen($this->storagetask) / 2);
		$returnData .= pack('H*', $this->storagetask);
		$factionContrib = $this->factioncontrib;
		$factionContribNew = Controller::inttosuckhex($factionContrib['deposit']);
		$factionContribNew .= Controller::inttosuckhex($factionContrib['freeDeposit']);
		$factionContribNew .= Controller::inttosuckhex($factionContrib['feat']);
		$returnData .= Controller::cuintoctet(strlen($factionContribNew) / 2);
		$returnData .= pack('H*', $factionContribNew);
		
		if (((Yii::app( )->params->version == '1.4.5' || Yii::app( )->params->version == '1.4.5.69') || Yii::app( )->params->version == '1.4.6'))
		{
			$returnData .= Controller::cuintoctet(strlen($this->forceData) / 2);
			$returnData .= pack('H*', $this->forceData);
			
			if ((Yii::app( )->params->version == '1.4.5.69' || Yii::app( )->params->version == '1.4.6'))
			{
				$returnData .= Controller::cuintoctet(strlen($this->onlineAward) / 2);
				$returnData .= pack('H*', $this->onlineAward);
				$returnData .= Controller::cuintoctet(strlen($this->profitData) / 2);
				$returnData .= pack('H*', $this->profitData);
			}
			
			if (Yii::app( )->params->version == '1.4.6')
			{
				$returnData .= Controller::cuintoctet(strlen($this->countryData) / 2);
				$returnData .= pack('H*', $this->countryData);
			}
			else
			{
				$returnData .= Controller::cuint($this->reserved22);
			}
			
			if (Yii::app( )->params->version == '1.4.5') 
			{
				$returnData .= strrev(pack('S', $this->reserved33 | 0 ));
			}
		}
		else
		{
			$returnData .= Controller::pack8int($this->reserved22);
			$returnData .= Controller::pack8int($this->reserved33);
		}
		
		$returnData .= Controller::pack8int($this->reserved44);
		
		if (((Yii::app( )->params->version == '1.4.5' || Yii::app( )->params->version == '1.4.5.69') || Yii::app( )->params->version == '1.4.6'))
		{
			$returnData .= Controller::pack8int($this->reserved55);
		}
		
		$returnData .= Controller::pack8int($this->pocketCapacity);
		$returnData .= Controller::pack8int($this->pocketTimestamp);
		$returnData .= Controller::pack8int($this->pocketMoney);
		
		if ($this->rolePocket == 0)
		{
			$returnData .= pack('H*', '00');
		}
		else 
		{
			$count = count($this->rolePocket);
			$returnData .= strrev(pack('C', $count));
			$roleItem = $this->rolePocket;
			$i = 12;
			
			while ($i < $count)
			{
				$returnData .= Controller::pack8int($roleItem[$i]['id']);
				$returnData .= Controller::pack8int($roleItem[$i]['pos']);
				$returnData .= Controller::pack8int($roleItem[$i]['count']);
				$returnData .= Controller::pack8int($roleItem[$i]['maxcount']);
				$returnData .= Controller::cuintoctet(strlen($roleItem[$i]['octet']) / 2);
				$returnData .= pack('H*', $roleItem[$i]['octet']);
				$returnData .= Controller::pack8int($roleItem[$i]['proctype']);
				$returnData .= Controller::pack8int($roleItem[$i]['data']);
				$returnData .= Controller::pack8int($roleItem[$i]['guid1']);
				$returnData .= Controller::pack8int($roleItem[$i]['guid2']);
				$returnData .= Controller::pack8int($roleItem[$i]['mask']);
				++$i;
			}
		}
		
		$returnData .= Controller::pack8int($this->pocketReserved1);
		$returnData .= Controller::pack8int($this->pocketReserved2);
		
		if ($this->roleInventory == 0)
		{
			$returnData .= pack('H*', '00');
		}
		else
		{
			$count = count($this->roleInventory);
			$returnData .= strrev(pack('C', $count));
			$roleItem = $this->roleInventory;
			$i = 12;
			
			while ($i < $count)
			{
				$returnData .= Controller::pack8int($roleItem[$i]['id']);
				$returnData .= Controller::pack8int($roleItem[$i]['pos']);
				$returnData .= Controller::pack8int($roleItem[$i]['count']);
				$returnData .= Controller::pack8int($roleItem[$i]['maxcount']);
				$returnData .= Controller::cuintoctet(strlen($roleItem[$i]['octet']) / 2);
				$returnData .= pack('H*', $roleItem[$i]['octet']);
				$returnData .= Controller::pack8int($roleItem[$i]['proctype']);
				$returnData .= Controller::pack8int($roleItem[$i]['data']);
				$returnData .= Controller::pack8int($roleItem[$i]['guid1']);
				$returnData .= Controller::pack8int($roleItem[$i]['guid2']);
				$returnData .= Controller::pack8int($roleItem[$i]['mask']);
				++$i;
			}
		}
		
		$returnData .= Controller::pack8int($this->storeCapacity);
		$returnData .= Controller::pack8int($this->storeMoney);
		
		if ($this->roleStore == 0)
		{
			$returnData .= pack('H*', '00');
		}
		else 
		{
			$count = count($this->roleStore);
			$returnData .= strrev(pack('C', $count));
			$roleItem = $this->roleStore;
			$i = 12;
			
			while ($i < $count)
			{
				$returnData .= Controller::pack8int($roleItem[$i]['id']);
				$returnData .= Controller::pack8int($roleItem[$i]['pos']);
				$returnData .= Controller::pack8int($roleItem[$i]['count']);
				$returnData .= Controller::pack8int($roleItem[$i]['maxcount']);
				$returnData .= Controller::cuintoctet(strlen($roleItem[$i]['octet']) / 2);
				$returnData .= pack('H*', $roleItem[$i]['octet']);
				$returnData .= Controller::pack8int($roleItem[$i]['proctype']);
				$returnData .= Controller::pack8int($roleItem[$i]['data']);
				$returnData .= Controller::pack8int($roleItem[$i]['guid1']);
				$returnData .= Controller::pack8int($roleItem[$i]['guid2']);
				$returnData .= Controller::pack8int($roleItem[$i]['mask']);
				++$i;
			}
		}
		
		$returnData .= strrev(pack('C', $this->storeSize1));
		$returnData .= strrev(pack('C', $this->storeSize2));
		
		if ($this->store1 == 0)
		{
			$returnData .= pack('H*', '00');
		}
		else 
		{
			$count = count($this->store1);
			$returnData .= strrev(pack('C', $count));
			$roleItem = $this->store1;
			$i = 12;
			
			while ($i < $count)
			{
				$returnData .= Controller::pack8int($roleItem[$i]['id']);
				$returnData .= Controller::pack8int($roleItem[$i]['pos']);
				$returnData .= Controller::pack8int($roleItem[$i]['count']);
				$returnData .= Controller::pack8int($roleItem[$i]['maxcount']);
				$returnData .= Controller::cuintoctet(strlen($roleItem[$i]['octet']) / 2);
				$returnData .= pack('H*', $roleItem[$i]['octet']);
				$returnData .= Controller::pack8int($roleItem[$i]['proctype']);
				$returnData .= Controller::pack8int($roleItem[$i]['data']);
				$returnData .= Controller::pack8int($roleItem[$i]['guid1']);
				$returnData .= Controller::pack8int($roleItem[$i]['guid2']);
				$returnData .= Controller::pack8int($roleItem[$i]['mask']);
				++$i;
			}
		}
		
		if ($this->store2 == 0)
		{
			$returnData .= pack('H*', '00');
		}
		else
		{
			$count = count($this->store2);
			$returnData .= Controller::cuintoctet($count);
			$roleItem = $this->store2;
			$i = 12;
			
			while ($i < $count)
			{
				$returnData .= Controller::pack8int($roleItem[$i]['id']);
				$returnData .= Controller::pack8int($roleItem[$i]['pos']);
				$returnData .= Controller::pack8int($roleItem[$i]['count']);
				$returnData .= Controller::pack8int($roleItem[$i]['maxcount']);
				$returnData .= Controller::cuintoctet(strlen($roleItem[$i]['octet']) / 2);
				$returnData .= pack('H*', $roleItem[$i]['octet']);
				$returnData .= Controller::pack8int($roleItem[$i]['proctype']);
				$returnData .= Controller::pack8int($roleItem[$i]['data']);
				$returnData .= Controller::pack8int($roleItem[$i]['guid1']);
				$returnData .= Controller::pack8int($roleItem[$i]['guid2']);
				$returnData .= Controller::pack8int($roleItem[$i]['mask']);
				++$i;
			}
		}
		
		$returnData .= Controller::pack8int($this->storeReserved);
		$returnData .= Controller::cuintoctet(strlen($this->taskData) / 2);
		$returnData .= pack('H*', $this->taskData);
		$returnData .= Controller::cuintoctet(strlen($this->taskComplete) / 2);
		$returnData .= pack('H*', $this->taskComplete);
		$returnData .= Controller::cuintoctet(strlen($this->taskFinishTime) / 2);
		$returnData .= pack('H*', $this->taskFinishTime);
		
		if ($this->taskInventory == 0)
		{
			$returnData .= pack('H*', '00');
		}
		else 
		{
			$count = count($this->taskInventory);
			$returnData .= strrev(pack('C', $count));
			$roleItem = $this->taskInventory;
			$i = 12;
			
			while ($i < $count)
			{
				$returnData .= Controller::pack8int($roleItem[$i]['id']);
				$returnData .= Controller::pack8int($roleItem[$i]['pos']);
				$returnData .= Controller::pack8int($roleItem[$i]['count']);
				$returnData .= Controller::pack8int($roleItem[$i]['maxcount']);
				$returnData .= Controller::cuintoctet(strlen($roleItem[$i]['octet']) / 2);
				$returnData .= pack('H*', $roleItem[$i]['octet']);
				$returnData .= Controller::pack8int($roleItem[$i]['proctype']);
				$returnData .= Controller::pack8int($roleItem[$i]['data']);
				$returnData .= Controller::pack8int($roleItem[$i]['guid1']);
				$returnData .= Controller::pack8int($roleItem[$i]['guid2']);
				$returnData .= Controller::pack8int($roleItem[$i]['mask']);
				++$i;
			}
		}
		
		$opcode = Controller::cuint(8002);
		$id = strrev(pack('I', rand(1, 9999 ) | 2147483648));
		$roleid2 = strrev(pack('I', $this->roleId | 0));
		$wtf = Controller::cuint(1);
		$length = Controller::cuint(strlen($id . $roleid2 . $wtf . $returnData));
		$packet = $opcode . $length . $id . $roleid2 . $wtf . $returnData;
		$data = Controller::sendpacket('gamedbd', $packet);
	}
	
	function Role($roleid, $multiple)
	{
		$opcode = Controller::cuint( 8003);
		$id = strrev(pack('I', rand(1, 9999 ) | 2147483648));
		$roleid = strrev(pack('I', $roleid | 0));
		$length = Controller::cuint( strlen($id . $roleid));
		$packet = $opcode . $length . $id . $roleid;
		
		if ($multiple == false)
		{
			$data = Controller::sendpacket('gamedbd', $packet);
			$this->parse($data);
			return null;
		}
		
		$this->packet = $packet;
	}
}
?>
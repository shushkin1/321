<?php

class Rolefaction
{
	var $unk1 = null;
	var $unk2 = null;
	var $roleId = null;
	var $roleName = null;
	var $factionId = null;
	var $class = null;
	var $post = null;
	var $other = null;
	
	function __construct($roleid)
	{
/*
		if (isset(Yii::app( )->params->license_key))
		{
			$license_key = str_replace('-', '', Yii::app( )->params->license_key);
			$checkLicense1 = hash('sha256', base64_encode($_SERVER['SERVER_ADDR']).'perfect world'.'fucking cheaters');
			
			if ($license_key != $checkLicense1)
			{
				exit('wrong license key');
			}
		}
		else
		{
			exit('wrong license key');
		}
*/
		$this->Rolefaction($roleid);
	}
	
	function parse($factionData)
	{
		$factionData = substr($factionData, 4);
		$length = 2 + hexdec(substr($factionData, 0, 2)) * 2;
		
		if ($length == strlen($factionData))
		{
			$factionData = substr($factionData, 2);
		}
		else
		{
			$factionData = substr($factionData, 4);
		}
		
		$this->unk1 = hexdec(substr($factionData, 0, 8));
		$factionData = substr($factionData, 8);
		$this->unk2 = hexdec(substr($factionData, 0, 8));
		$factionData = substr($factionData, 8);
		$this->roleId = hexdec(substr($factionData, 0, 8));
		$factionData = substr($factionData, 8);
		$lengthName = hexdec(substr($factionData, 0, 2)) * 2;
		$factionData = substr($factionData, 2);
		$this->roleName = iconv('UTF-16LE', 'UTF-8', Controller::hextostr(substr($factionData, 0, $lengthName)));
		$factionData = substr($factionData, $lengthName);
		$this->factionId = hexdec(substr($factionData, 0, 8));
		$factionData = substr($factionData, 8);
		$this->class = hexdec(substr($factionData, 0, 2));
		$factionData = substr($factionData, 2);
		$this->post = hexdec(substr($factionData, 0, 2));
		$factionData = substr($factionData, 2);
		$this->other = $factionData;
	}
	
	function Rolefaction($roleId)
	{
		Controller::cuint(4607);
		$id = strrev(pack('I', rand(1, 9999) | 2147483648));
		$roleId = strrev(pack('I', $roleId | 0));
		$factionId = strrev(pack('I', '0' | 0));
		$length = Controller::cuint(strlen($id . $factionId . $roleId));
		$packet = $opcode.$length.$id .$factionId.$roleId;
		$data = $opcode = Controller::sendpacket('gamedbd', $packet);
		$this->parse($data);
	}
}

?>

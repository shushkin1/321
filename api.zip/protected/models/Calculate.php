<?php
class Calculate 
{
    public function levelUp($class,$level,$stamina,$intelligence)
    {
        $params = array(
            '0' => array( // warrior
                'hp' => '30',
                'hpStamina' => '15',
                'mp' => '18',
                'mpIntelligence' => '9',
                'minPhys' => '1.03',
                'maxPhys' => '1.03',
                'minMag' => '0.001',
                'maxMag' => '0.001',
            ),
            '1' => array( // mage
                'hp' => '20',
                'hpStamina' => '10',
                'mp' => '28',
                'mpIntelligence' => '14',
                'minPhys' => '0.2',
                'maxPhys' => '0.2',
                'minMag' => '1.05',
                'maxMag' => '1.05',
            ),
            '2' => array( // shaman
                'hp' => '20',
                'hpStamina' => '10',
                'mp' => '28',
                'mpIntelligence' => '14',
                'minPhys' => '0.2',
                'maxPhys' => '0.2',
                'minMag' => '1.05',
                'maxMag' => '1.05',
            ),
            '3' => array( // druid
                'hp' => '24',
                'hpStamina' => '12',
                'mp' => '24',
                'mpIntelligence' => '12',
                'minPhys' => '0.62',
                'maxPhys' => '0.62',
                'minMag' => '0.63',
                'maxMag' => '0.63',
            ),
            '4' => array( // werewolf
                'hp' => '34',
                'hpStamina' => '17',
                'mp' => '14',
                'mpIntelligence' => '7',
                'minPhys' => '1.03',
                'maxPhys' => '1.03',
                'minMag' => '0.001',
                'maxMag' => '0.001',
            ),
            '5' => array( // assasin
                'hp' => '26',
                'hpStamina' => '13',
                'mp' => '22',
                'mpIntelligence' => '10',
                'minPhys' => '1.03',
                'maxPhys' => '1.03',
                'minMag' => '0.001',
                'maxMag' => '0.001',
            ),
            '6' => array( // archer
                'hp' => '26',
                'hpStamina' => '13',
                'mp' => '22',
                'mpIntelligence' => '10',
                'minPhys' => '1.03',
                'maxPhys' => '1.03',
                'minMag' => '0.001',
                'maxMag' => '0.001',
            ),
            '7' => array( // priest
                'hp' => '20',
                'hpStamina' => '10',
                'mp' => '28',
                'mpIntelligence' => '14',
                'minPhys' => '0.21',
                'maxPhys' => '0.21',
                'minMag' => '1.05',
                'maxMag' => '1.05',
            ),
            '8' => array( // guardian
                'hp' => '30',
                'hpStamina' => '15',
                'mp' => '18',
                'mpIntelligence' => '9',
                'minPhys' => '1.03',
                'maxPhys' => '1.03',
                'minMag' => '0.001',
                'maxMag' => '0.001',
            ),
            '9' => array( // mystic
                'hp' => '20',
                'hpStamina' => '10',
                'mp' => '28',
                'mpIntelligence' => '14',
                'minPhys' => '0.2',
                'maxPhys' => '0.2',
                'minMag' => '1.05',
                'maxMag' => '1.05',
            ),
        );

        $data = $params[$class];
        $level = $level - 1;

        $hp = round(($level * $data['hp']) + ($stamina * $data['hpStamina']));
        $mp = round(($level * $data['mp']) + ($intelligence * $data['mpIntelligence']));
        $minPhys = round($level * $data['minPhys']);
        $maxPhys = round($level * $data['maxPhys']);
        $minMag = ceil($level * $data['minMag']);
        $maxMag = ceil($level * $data['maxMag']);

        return array(
            'hp' => $hp,
            'mp' => $mp,
            'minPhys' => $minPhys,
            'maxPhys' => $maxPhys,
            'minMag' => $minMag,
            'maxMag' => $maxMag,
        );
    }
}
<?php

class Multiple
{
	protected $socket = null;
	
	function __construct()
	{
		$this->socket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
		$bind = socket_connect($this->socket, '127.0.0.1', '29400');
	}
	
	function sendPacket($data)
	{
		socket_send($this->socket, $data, 524288, 0);
		$reply = socket_recv($this->socket, $answer, 524288, 0);
		$packet = $answer;
		$finish = '0';
		
		while ($finish == '0')
		{
			$checkReply = substr($packet, 2);
			$length = 1 + hexdec(bin2hex(substr( $checkReply, 0, 1)));
			$length2 = 2 + (hexdec(bin2hex(substr($checkReply, 0, 2))) - 32768);
			$length3 = 4 + (hexdec(bin2hex(substr($checkReply, 0, 4))) - 3221225472);
			
			if ($length == strlen($checkReply))
			{
				$finish = '1';
				continue;
			}
			
			
			if ($length2 == strlen($checkReply))
			{
				$finish = '1';
				continue;
			}
			
			
			if ($length3 == strlen($checkReply))
			{
				$finish = '1';
				continue;
			}
			
			$reply = socket_recv($this->socket, $answer, 524288, 0);
			$packet .= $answer;
		}
		
		$packet = $query = bin2hex($packet);
		return $packet;
	}
}

?>

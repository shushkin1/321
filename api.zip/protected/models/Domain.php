<?php

class Domain
{
	var $domain = null;
	
	function __construct()
	{
/*
		if (isset(Yii::app( )->params->license_key))
		{
			$license_key = str_replace('-', '', Yii::app( )->params->license_key);
			$checkLicense1 = hash('sha256', base64_encode($_SERVER['SERVER_ADDR']).'perfect world'.'fucking cheaters');
			
			if ($license_key != $checkLicense1)
			{
				exit('wrong license key');
			}
		}
		else
		{
			exit('wrong license key');
		}
*/
		$this->Domain();
	}
	
	function parse($data)
	{
		$data = substr($data, 4);
		$length = 2 + hexdec(substr($data, 0, 2)) * 2;
		$length2 = 4 + 2 * (hexdec(substr($data, 0, 4)) - 32768);
		
		if ($length == strlen($data))
		{
			$data = substr($data, 2);
		}
		else
		{
			if ($length2 == strlen($data))
			{
				$data = substr($data, 4);
			}
			else 
			{
				$data = substr($data, 8);
			}
		}
		
		$data = substr($data, 12);
		$count = hexdec(substr($data, 0, 2));
		$data = substr($data, 2);
		
		if (0 < $count)
		{
			$i = 4;
			
			while ($i < $count)
			{
				$domain[$i]['id'] = hexdec(substr($data, 0, 4));
				$data = substr($data, 4);
				$domain[$i]['level'] = hexdec(substr($data, 0, 4));
				$data = substr($data, 4);
				$domain[$i]['owner'] = hexdec(substr($data, 0, 8));
				$data = substr($data, 8);
				
				if (!empty($domain[$i]['owner']))
				{
					$factionInfo = new Factioninfo($domain[$i]['owner']);
					$domain[$i]['owner_name'] = $factionInfo->factionName;
				}
				
				$domain[$i]['occupy_time'] = hexdec(substr($data, 0, 8));
				$data = substr($data, 8);
				$domain[$i]['attacker'] = hexdec(substr($data, 0, 8));
				$data = substr($data, 8);
				
				if (!empty($domain[$i]['attacker']))
				{
					$factionInfo = new Factioninfo($domain[$i]['attacker']);
					$domain[$i]['attacker_name'] = $factionInfo->factionName;
				}
				
				$domain[$i]['deposit'] = hexdec(substr($data, 0, 8));
				$data = substr($data, 8);
				$domain[$i]['cutoff_time'] = hexdec(substr($data, 0, 8));
				$data = substr($data, 8);
				$domain[$i]['battle_time'] = hexdec(substr($data, 0, 8));
				$data = substr($data, 8);
				$domain[$i]['bonus_time'] = hexdec(substr($data, 0, 8));
				$data = substr($data, 8);
				$domain[$i]['color'] = hexdec(substr($data, 0, 8));
				$data = substr($data, 8);
				$domain[$i]['status'] = hexdec(substr($data, 0, 8));
				$data = substr($data, 8);
				$domain[$i]['timeout'] = hexdec(substr($data, 0, 8));
				$data = substr($data, 8);
				$domain[$i]['max_bonus'] = hexdec(substr($data, 0, 8));
				$data = substr($data, 8);
				$domain[$i]['date'] = hexdec(substr($data, 0, 8));
				$data = substr($data, 8);
				$lengthBids = hexdec(substr($data, 0, 2)) * 2;
				$data = substr($data, 2);
				$domain[$i]['bids'] = substr($data, 0, $lengthBids);
				$data = substr( $data, $lengthBids );
				$domain[$i]['unk'] = substr($data, 0, 6);
				$data = substr($data, 6);
				++$i;
			}
			
			$this->domain = $domain;
		}
		
	}
	
	function Domain()
	{
		Controller::cuint(863);
		$id = strrev(pack('I', rand(1, 9999) | 2147483648));
		$domain = strrev(pack('I', 1 | 0));
		$length = Controller::cuint(strlen($id . $domain));
		$packet = $opcode.$length.$id.$domain;
		$data = $opcode = Controller::sendpacket('gamedbd', $packet);
		$this->parse($data);
	}
}

?>

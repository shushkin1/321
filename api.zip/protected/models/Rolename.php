<?php

class Rolename
{
	var $roleid = null;
	var $name = null;
	var $newname = null;
	
	function __construct($name)
	{
/*
		if (isset(Yii::app( )->params->license_key))
		{
			$license_key = str_replace('-', '', Yii::app( )->params->license_key);
			$checkLicense1 = hash('sha256', base64_encode($_SERVER['SERVER_ADDR']).'perfect world'.'fucking cheaters');
			
			if ($license_key != $checkLicense1)
			{
				exit('wrong license key');
			}
		}
		else 
		{
			exit('wrong license key');
		}
*/
		$this->Rolename($name);
	}
	
	function parse($data)
	{
		$data = substr($data, 4);
		$length = 2 + hexdec(substr($data, 0, 2)) * 2;
		
		if ($length == strlen($data))
		{
			$data = substr($data, 2);
		}
		else
		{
			$data = substr($data, 4);
		}
		
		$data = substr($data, 16);
		$roleid = substr($data, 0, 8);
		
		if ($roleid != 'ffffffff')
		{
			$this->roleid = hexdec($roleid);
			return null;
		}
		
		$this->roleid = '';
	}
	
	function save()
	{
		$opcode = Controller::cuint(3404);
		$id = strrev(pack('I', rand( 1, 9999 ) | 2147483648));
		$roleid = strrev(pack('I', $this->roleid | 0));
		$name = iconv('UTF-8', 'UTF-16LE', $this->name);
		$lname = Controller::cuint(strlen($name));
		$newname = iconv('UTF-8', 'UTF-16LE', $this->newname);
		$lnewname = Controller::cuint(strlen($newname));
		$length = Controller::cuint(strlen($id.$roleid.$lname.$name.$lnewname.$newname));
		$packet = $opcode.$length.$id.$roleid.$lname.$name.$lnewname.$newname;
		$data = Controller::sendpacket('gamedbd', $packet);
	}
	
	function Rolename($name)
	{
		$opcode = Controller::cuint(3033);
		$id = strrev(pack('I', rand(1, 9999) | 2147483648));
		$name = iconv('UTF-8', 'UTF-16LE', $name);
		$lname = Controller::cuint(strlen($name));
		$reason = Controller::cuint(0);
		$length = Controller::cuint(strlen($id.$lname.$name.$reason));
		$packet = $opcode.$length.$id.$lname.$name.$reason;
		$data = Controller::sendpacket('gamedbd', $packet);
		$this->parse($data);
	}
}

?>
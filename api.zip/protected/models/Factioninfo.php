<?php
class Factioninfo 
{
	var $factionName = null;
	var $other = null;
	
	function __construct($factionId) 
	{
/*
		if (isset(Yii::app( )->params->license_key))
		{
			$license_key = str_replace('-', '', Yii::app( )->params->license_key);
			$checkLicense1 = hash('sha256', base64_encode($_SERVER['SERVER_ADDR']).'perfect world'.'fucking cheaters');
			
			if ($license_key != $checkLicense1)
			{
				exit('wrong license key');
			}
		}
		else
		{
			exit('wrong license key');
		}
*/
		$this->Factioninfo($factionId);
	}
	
	function parse($factionData)
	{
		$factionData = substr($factionData, 4);
		$length = 2 + hexdec(substr($factionData, 0, 2)) * 2;
		
		if ($length == strlen($factionData))
		{
			$factionData = substr($factionData, 2);
		}
		else
		{
			$factionData = substr($factionData, 4);
		}
		
		$factionData = substr($factionData, 24);
		$lengthName = hexdec(substr($factionData, 0, 2)) * 2;
		$factionData = substr($factionData, 2);
		$this->factionName = iconv('UTF-16LE', 'UTF-8', Controller::hextostr(substr($factionData, 0, $lengthName)));
		$factionData = substr($factionData, $lengthName);
		$this->other = $factionData;
	}
	
	function Factioninfo($factionId)
	{
		Controller::cuint(4606);
		$id = strrev(pack('I', rand(1, 9999) | 2147483648));
		$factionId = strrev(pack('I', $factionId | 0));
		$length = Controller::cuint(strlen($id.$factionId));
		$packet = $opcode.$length.$id.$factionId;
		$data = $opcode = Controller::sendpacket('gamedbd', $packet);
		$this->parse($data);
	}
}

?>
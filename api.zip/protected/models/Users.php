<?php

/**
 * This is the model class for table "users".
 *
 * The followings are the available columns in table 'users':
 * @property integer $ID
 * @property string $name
 * @property string $passwd
 * @property string $Prompt
 * @property string $answer
 * @property string $truename
 * @property string $idnumber
 * @property string $email
 * @property string $mobilenumber
 * @property string $province
 * @property string $city
 * @property string $phonenumber
 * @property string $address
 * @property string $postalcode
 * @property integer $gender
 * @property string $birthday
 * @property string $creatime
 * @property string $qq
 * @property string $passwd2
 */
class Users extends CActiveRecord
{
	/**
	 * Returns the static model of the specified AR class.
	 * @return Users the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}

	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'users';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('passwd, creatime', 'required'),
			array('ID, gender', 'numerical', 'integerOnly'=>true),
			array('name, Prompt, answer, truename, idnumber, mobilenumber, province, city, phonenumber, qq', 'length', 'max'=>32),
			array('passwd, email, address, passwd2', 'length', 'max'=>64),
			array('postalcode', 'length', 'max'=>8),
			array('birthday', 'safe'),
		);
	}

	public function scopes()
    {
        return array(
            'idname'=>array(
            	'select' => 'ID, name',
            ),
        );
    }

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'ID' => 'ID',
			'name' => 'Name',
			'passwd' => 'Passwd',
			'Prompt' => 'Prompt',
			'answer' => 'Answer',
			'truename' => 'Truename',
			'idnumber' => 'Idnumber',
			'email' => 'Email',
			'mobilenumber' => 'Mobilenumber',
			'province' => 'Province',
			'city' => 'City',
			'phonenumber' => 'Phonenumber',
			'address' => 'Address',
			'postalcode' => 'Postalcode',
			'gender' => 'Gender',
			'birthday' => 'Birthday',
			'creatime' => 'Creatime',
			'qq' => 'Qq',
			'passwd2' => 'Passwd2',
		);
	}

}
<?php

class Roles
{
	var $roles = null;
	var $packet = null;
	
	function __construct($userid, $multiple = false)
	{
/*
		if (isset(Yii::app( )->params->license_key ))
		{
			$license_key = str_replace('-', '', Yii::app( )->params->license_key);
			$checkLicense1 = hash('sha256', base64_encode($_SERVER['SERVER_ADDR'] ).'perfect world'.'fucking cheaters');
			
			if ($license_key != $checkLicense1)
			{
				exit('wrong license key');
			}
		}
		else
		{
			exit('wrong license key');
		}
*/
		$this->Roles($userid, $multiple);
	}
	
	function parse($data)
	{
		$data = substr($data, 4);
		$length = 2 + hexdec(substr($data, 0, 2)) * 2;
		
		if ($length == strlen($data )) 
		{
			$data = substr($data, 2);
		}
		else 
		{
			$data = substr($data, 4);
		}
		
		$data = substr($data, 16);
		$count = hexdec(substr($data, 0, 2));
		$data = substr($data, 2);
		
		if (0 < $count)
		{
			$i = 4;
			
			while ($i < $count)
			{
				$uroles[$i]['roleid'] = hexdec(substr($data, 0, 8));
				$data = substr($data, 8);
				$namelength = hexdec(substr($data, 0, 2)) * 2;
				$data = substr($data, 2);
				$uroles[$i]['rolename'] = iconv('UTF-16LE', 'UTF-8', pack('H*', substr($data, 0, $namelength)));
				$data = substr($data, $namelength);
				++$i;
			}
			
			$this->roles = $uroles;
		}
		
	}
	
	function Roles($userId, $multiple)
	{
		$opcode = Controller::cuint(3401);
		$id = strrev(pack('I', rand(1, 9999 ) | 2147483648));
		$userId = strrev(pack('I', $userId | 0));
		$length = Controller::cuint(strlen($id.$userId));
		$packet = $opcode.$length.$id.$userId;
		
		if($multiple == false)
		{
			$data = Controller::sendpacket('gamedbd', $packet);
			$this->parse($data);
			return null;
		}
		
		$this->packet = $packet;
	}
}

?>
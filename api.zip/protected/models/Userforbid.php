<?php

class Userforbid
{
	var $operation = null;
	var $gm = null;
	var $source = null;
	var $userid = null;
	var $time = null;
	var $reason = null;
	
	function __construct()
	{
/*
		if (isset( Yii::app( )->params->license_key ))
		{
			$license_key = str_replace('-', '', Yii::app( )->params->license_key);
			$checkLicense1 = hash('sha256', base64_encode($_SERVER['SERVER_ADDR']).'perfect world'.'fucking cheaters');
			
			if ($license_key != $checkLicense1)
			{
				exit('wrong license key');
				return null;
			}
		}
		else 
		{
			exit('wrong license key');
		}
*/
	}
	
	function save() 
	{
		$returnData = Controller::cuint($this->operation);
		$returnData .= Controller::pack8int($this->gm);
		$returnData .= Controller::pack8int($this->source);
		$returnData .= Controller::pack8int($this->userid);
		$returnData .= Controller::pack8int($this->time);
		$this->reason = iconv('UTF-8', 'UTF-16LE', $this->reason);
		$returnData .= Controller::cuint(strlen($this->reason));
		$returnData .= $this->reason;
		$opcode = Controller::cuint(8004);
		$id = strrev(pack('I', rand(1, 9999) | 2147483648));
		$length = Controller::cuint( strlen($id.$returnData));
		$packet = $opcode.$length.$id.$returnData;
		$data = Controller::sendpacket('gamedbd', $packet);
	}
}

?>
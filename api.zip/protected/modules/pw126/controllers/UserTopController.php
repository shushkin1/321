<?php
class UserTopController extends Controller
{
    public function actionIndex()
    {
        $connection = Yii::app()->db;
        $sql = "SELECT point.uid FROM point LEFT JOIN auth ON point.uid = auth.userid WHERE auth.userid IS NULL AND point.zoneid='" . Yii::app()->params->zoneid . "'";
        $command = $connection->createCommand($sql);
        $success = $command->queryAll();

        for ($i = 0, $countUsers = count($success); $i < $countUsers; $i++) {
            $userId = $success[$i]['uid'];
            echo $userId."\n";
            $roles = new RolesPw126($userId);
            $roles = $roles->roles;
            if (isset($roles) AND !empty($roles['0']['roleid'])) {
                for ($i2 = 0, $countRoles = count($roles); $i2 < $countRoles; $i2++) {
                    $roleId = $roles[$i2]['roleid'];
                    $role = new RolePw126($roleId);

                    $userTop = new UsertopPw126;
                    $userTop->id = $role->roleId;
                    $userTop->name = $role->roleName;
                    $userTop->race = $role->roleRace;
                    $userTop->class = $role->roleClass;
                    $userTop->gender = $role->roleGender;
                    $userTop->create = $role->roleCreateTime;
                    $userTop->level = $role->level;
                    $userTop->cultivation = $role->cultivation;
                    $userTop->hp = $role->health;
                    $userTop->mp = $role->mana;
                    $userTop->pariah = $role->pariahTime;
                    $userTop->reputation = $role->reputation;
                    $userTop->online = $role->timeUsed;
                    $userTop->feat = $role->factioncontrib['feat'];
                    $userTop->lastlogin = $role->roleLastLogin;
                    $userTop->userid = $role->userid;
                    if ($userTop->validate()) {
                        $top = UsertopPw126::model()->findByPk($userTop->id);
                        if (isset($top) AND !empty($top->name)) {
                            $top->delete();
                        }
                        $userTop->save();
                    }
                    unset($userTop);
                    unset($role);
                }
                unset($roles);
                set_time_limit(30);
            }
        }
        unset($success);
    }
}
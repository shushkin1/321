<?php
class ChangePasswdController extends Controller
{
    public $error = 1;
    public $status = 0;

    public function actions()
    {
        return array(
            'quote' => array(
                'class' => 'CWebServiceAction',
                'serviceUrl' => Yii::app()->createAbsoluteUrl('pw126/changePasswd/quote', array('ws' => 1)),
                'wsdlUrl' => Yii::app()->createAbsoluteUrl('pw126/changePasswd/quote'),
            ),
        );
    }

    /**
     * @param string логин
     * @param string пароль
     * @return array результат
     * @soap
     */
    public function changePasswd($name, $passwd)
    {
        $user = UsersPw126::model()->findByAttributes(array('name' => $name));
        if (isset($user->ID)) {
            $user->passwd = $passwd;
            $user->passwd2 = $passwd;
            $user->save();

            $this->error = 0;
            $this->status = 1;
        }

        return array(
            'error' => $this->error,
            'status' => $this->status
        );
    }

    public function actionCurl()
    {
        $data = unserialize($_GET['data']);
        $result = $this->changePasswd($data['name'], $data['password']);
        echo serialize($result);
    }
}
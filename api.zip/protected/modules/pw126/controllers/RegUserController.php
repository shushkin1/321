<?php
class RegUserController extends Controller
{
    public $error = 1;
    public $status = 0;

    public function actions()
    {
        return array(
            'quote' => array(
                'class' => 'CWebServiceAction',
                'serviceUrl' => Yii::app()->createAbsoluteUrl('pw126/regUser/quote', array('ws' => 1)),
                'wsdlUrl' => Yii::app()->createAbsoluteUrl('pw126/regUser/quote'),
            ),
        );
    }

    /**
     * @param string логин
     * @param string пароль
     * @param string email
     * @return array результат
     * @soap
     */
    public function regUser($name, $passwd, $email)
    {
        $user = UsersPw126::model()->findByAttributes(array('name' => $name));
        if (!isset($user['ID'])) {
            $connection = Yii::app()->db;
            $sql = "call adduser(:username,:passwd,'0','0','0','0',:email,'0','0','0','0','0','0','','','0',:passwd2)";
            $command = $connection->createCommand($sql);
            $command->bindParam(":username", $name, PDO::PARAM_STR);
            $command->bindParam(":passwd", $passwd, PDO::PARAM_STR);
            $command->bindParam(":email", $email, PDO::PARAM_STR);
            $command->bindParam(":passwd2", $passwd, PDO::PARAM_STR);
            $success = $command->query();
            if ($success) {
                $this->error = 0;
                $this->status = 1;
                if (Yii::app()->params->addgold == '1') {
                    $user = UsersPw126::model()->findByAttributes(array('name' => $name));
                    $sql = "call usecash(" . $user->ID . "," . Yii::app()->params->zoneid . ",0," . Yii::app()->params->aid . ",0," . Yii::app()->params->gold . ",1,@error)";
                    $command = $connection->createCommand($sql);
                    $success = $command->query();
                }
            }
        } else {
            $this->error = 3;
            $this->status = 0;
        }

        return array(
            'error' => $this->error,
            'status' => $this->status,
        );
    }

    public function actionCurl()
    {
        $data = unserialize($_GET['data']);
        $result = $this->regUser($data['name'], $data['password'], $data['email']);
        echo serialize($result);
    }
}
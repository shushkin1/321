<?php
class GetUserController extends Controller
{
    public $error = 1;
    public $status = 0;
    public $data = '';

    public function actions()
    {
        return array(
            'quote' => array(
                'class' => 'CWebServiceAction',
                'serviceUrl' => Yii::app()->createAbsoluteUrl('pw126/getUser/quote', array('ws' => 1)),
                'wsdlUrl' => Yii::app()->createAbsoluteUrl('pw126/getUser/quote'),
            ),
        );
    }

    /**
     * @param string name
     * @return array
     * @soap
     */
    public function getUser($name)
    {
        $user = UsersPw126::model()->findByAttributes(array('name' => $name));
        if (isset($user['ID'])) {
            $this->error = 0;
            $this->status = 1;
            $this->data = array(
                'id' => $user->ID,
                'name' => $user->name,
                'email' => $user->email,
            );

        }

        return array(
            'error' => $this->error,
            'status' => $this->status,
            'data' => $this->data,
        );
    }

    public function actionCurl()
    {
        $data = unserialize($_GET['data']);
        $result = $this->getUser($data['name']);
        echo serialize($result);
    }
}
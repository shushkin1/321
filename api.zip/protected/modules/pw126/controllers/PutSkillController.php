<?php
class PutSkillController extends Controller
{
    public $error = 1;
    public $status = 0;
    public $data = '';

    public function actions()
    {
        return array(
            'quote' => array(
                'class' => 'CWebServiceAction',
                'serviceUrl' => Yii::app()->createAbsoluteUrl('pw126/putSkill/quote', array('ws' => 1)),
                'wsdlUrl' => Yii::app()->createAbsoluteUrl('pw126/putSkill/quote'),
            ),
        );
    }


    /**
     * @param int roleid
     * @param int uid
     * @param array data
     * @return array результат
     * @soap
     */
    public function putSkill($roleid, $uid = '', $skill)
    {
        if (isset($roleid)) {
            $role = new RolePw126($roleid);

            $count = count($role->skills);
            $role->skills[$count]['id'] = $skill['id'];
            $role->skills[$count]['progress'] = $skill['progress'];
            $role->skills[$count]['level'] = $skill['level'];

            $controller = Yii::app()->createController('pw126/checkOnline/default');
            $result = $controller[0]->checkOnline($role->userid);
            if ($result['error'] == '2') {
                $role->save();

                $this->error = '0';
                $this->status = '1';
            } else {
                $this->error = '3'; // role online
                $this->status = '0';
            }
        }


        return array(
            'error' => $this->error,
            'status' => $this->status,
            'data' => $this->data,
        );
    }

    public function actionCurl()
    {
        $data = unserialize($_GET['data']);
        $result = $this->putSkill($data['id'], $data['uid'], $data['data']);
        echo serialize($result);
    }
}
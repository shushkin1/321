<?php
class ChangeNameController extends Controller
{
    public $error = 1;
    public $status = 0;
    public $data = '';

    public function actions()
    {
        return array(
            'quote' => array(
                'class' => 'CWebServiceAction',
                'serviceUrl' => Yii::app()->createAbsoluteUrl('pw126/changeName/quote', array('ws' => 1)),
                'wsdlUrl' => Yii::app()->createAbsoluteUrl('pw126/changeName/quote'),
            ),
        );
    }

    /**
     * @param int id
     * @param string name
     * @param string new name
     * @return array результат
     * @soap
     */
    public function changeName($id, $name, $newname)
    {
        if (isset($name) AND isset($id)) {
            $roleid = new RolenamePw126($newname);

            if (isset($roleid->roleid) AND !empty($roleid->roleid)) {
                $this->error = '5'; // nickname exists
            } else {
                $role = new RolePw126($id);
                $controller = Yii::app()->createController('pw126/checkOnline/default');
                $result = $controller[0]->checkOnline($role->userid);

                if ($result['error'] == '2') {
                    $roleid->roleid = $id;
                    $roleid->name = $name;
                    $roleid->newname = $newname;
                    $roleid->save();

                    $this->status = '1';
                    $this->error = '0';
                } else {
                    $this->error = '3'; // role online
                    $this->status = '0';
                }
            }
        }

        return array(
            'error' => $this->error,
            'status' => $this->status,
            'data' => $this->data,
        );
    }

    public function actionCurl()
    {
        $data = unserialize($_GET['data']);
        $result = $this->changeName($data['id'], $data['name'], $data['newname']);
        echo serialize($result);
    }
}
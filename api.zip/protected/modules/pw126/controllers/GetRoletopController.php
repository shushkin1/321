<?php
class GetRoletopController extends Controller
{
    public $error = 1;
    public $status = 0;
    public $data = '';

    public function actions()
    {
        return array(
            'quote' => array(
                'class' => 'CWebServiceAction',
                'serviceUrl' => Yii::app()->createAbsoluteUrl('pw126/getRoletop/quote', array('ws' => 1)),
                'wsdlUrl' => Yii::app()->createAbsoluteUrl('pw126/getRoletop/quote'),
            ),
        );
    }

    /**
     * @param int roleid
     * @return array результат
     * @soap
     */
    public function getRoletop($roleid)
    {
        if (isset($roleid)) {
            $role = new RolePw126($roleid);

            if (!empty($role->spouse)) {
                $role2 = new RolePw126($role->spouse);
                $spouse = $role2->roleName;
            } else {
                $spouse = '';
            }

            $rolefaction = new RolefactionPw126($roleid);
            if (isset($rolefaction->roleId) AND $rolefaction->roleId != '0') {
                $factioninfo = new FactioninfoPw126($rolefaction->factionId);
                $faction = $factioninfo->factionName;
                $post = $rolefaction->post;
                $factionId = $rolefaction->factionId;
            } else {
                $faction = '';
                $post = '';
                $factionId = '';
            }

            $respond = array(
                'name' => $role->roleName,
                'class' => $role->roleClass,
                'gender' => $role->roleGender,
                'create' => $role->roleCreateTime,
                'level' => $role->level,
                'cultivation' => $role->cultivation,
                'hp' => $role->health,
                'mp' => $role->mana,
                'pariah' => $role->pariahTime,
                'reputation' => $role->reputation,
                'online' => $role->timeUsed,
                'feat' => '',
                'spouse' => $spouse,
                'stamina' => $role->stamina,
                'intelligence' => $role->intelligence,
                'agility' => $role->agility,
                'strong' => $role->strong,
                'inventory' => $role->roleInventory,
                'faction' => $faction,
                'post' => $post,
                'factionId' => $factionId,
            );

            $this->data = $respond;
            $this->error = '0';
            $this->status = '1';
        }


        return array(
            'error' => $this->error,
            'status' => $this->status,
            'data' => $this->data,
        );
    }

    public function actionCurl()
    {
        $data = unserialize($_GET['data']);
        $result = $this->getRoletop($data['roleId']);
        echo serialize($result);
    }
}
<?php
class SendMailController extends Controller
{
	public $error = 1;
	public $status = 0;
	public $data = '';

    public function actions()
    {
        return array(
            'quote'=>array(
                'class'=>'CWebServiceAction',
                'serviceUrl' => Yii::app()->createAbsoluteUrl('pw126/sendMail/quote', array('ws' => 1)),
                'wsdlUrl' => Yii::app()->createAbsoluteUrl('pw126/sendMail/quote'),
            ),
        );
    }
		
    /**
     * @param int roleid
     * @param array item
     * @return array результат
     * @soap
     */
    public function sendMail($roleid,$item)
    {
    	if(isset($roleid) AND isset($item))
    	{
            $mail = new MailPw126($roleid, $item, 'Mail', 'Mail', 32);
            $mail->save();

	    	$this->error = '0';
	    	$this->status = '1';
    	}

        return array(
			'error'=>$this->error,
			'status'=>$this->status,
			'data'=>$this->data,
		);
    }

    /**
     * @param string title
     * @param string text
     * @param array names and ids
     * @param array item
     * @return array result
     * @soap
     */
    public function sendMails($title,$text,$names_and_ids,$item)
    {
        if(isset($names_and_ids) AND isset($item))
        {
            foreach($names_and_ids as $key => $value){
                $allow = '1';
                if(!preg_match('/^[0-9]+$/i', $value)){
                    $roleid = new RolenamePw126($value);
                    if (isset($roleid->roleid) AND !empty($roleid->roleid)) {
                        $names_and_ids[$key] = $roleid->roleid;
                    } else {
                        unset($names_and_ids[$key]);
                        $not_exists_names[] = $value;
                        $allow = '0';
                    }
                }

                if($allow=='1'){
                    $mail = new MailPw126($names_and_ids[$key], $item, $title, $text);
                    $mail->save();
                }
            }

            $this->data = $not_exists_names;
            $this->error = '0';
            $this->status = '1';
        }

        return array(
            'error'=>$this->error,
            'status'=>$this->status,
            'data'=>$this->data,
        );
    }

    public function actionCurl()
    {
        $data = unserialize($_GET['data']);
        if(!isset($data['title'])){
            $result = $this->sendMail($data['id'],$data['data']);
        } else {
            $result = $this->sendMails($data['title'],$data['text'],$data['names_and_ids'],$data['item']);
        }
        echo serialize($result);
    }
}
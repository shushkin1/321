<?php
class GetRolesController extends Controller
{
    public $error = 1;
    public $status = 0;
    public $data = '';

    public function actions()
    {
        return array(
            'quote' => array(
                'class' => 'CWebServiceAction',
                'serviceUrl' => Yii::app()->createAbsoluteUrl('pw126/getRoles/quote', array('ws' => 1)),
                'wsdlUrl' => Yii::app()->createAbsoluteUrl('pw126/getRoles/quote'),
            ),
        );
    }

    /**
     * @param string name
     * @return array результат
     * @soap
     */
    public function getRoles($name)
    {
        $id = UsersPw126::model()->findByAttributes(array('name' => $name));
        if (isset($id->ID) AND !empty($id->ID)) {
            $roles = new RolesPw126($id->ID);
            $roles = $roles->roles;
            for ($i = 0, $count = count($roles); $i < $count; $i++) {
                $roleId = $roles[$i]['roleid'];
                $role = new RolePw126($roleId);
                $roles[$i]['class'] = $role->roleClass;
                $roles[$i]['level'] = $role->level;
            }

            if (isset($roles['0']['roleid']) AND !empty($roles['0']['roleid'])) {
                $this->data = $roles;
                $this->status = '1';
                $this->error = '0';
            } else {
                $this->error = '4';
            }
        }

        return array(
            'error' => $this->error,
            'status' => $this->status,
            'data' => $this->data,
        );
    }

    public function actionCurl()
    {
        $data = unserialize($_GET['data']);
        $result = $this->getRoles($data['name']);
        echo serialize($result);
    }
}
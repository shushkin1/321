<?php
class SetParamController extends Controller
{
    public $error = 1;
    public $status = 0;
    public $data = '';

    public function actions()
    {
        return array(
            'quote' => array(
                'class' => 'CWebServiceAction',
                'serviceUrl' => Yii::app()->createAbsoluteUrl('pw126/setParam/quote', array('ws' => 1)),
                'wsdlUrl' => Yii::app()->createAbsoluteUrl('pw126/setParam/quote'),
            ),
        );
    }

    /**
     * @param int roleid
     * @return array результат
     * @soap
     */
    public function setSoul($roleid)
    {
        if (isset($roleid)) {
            $role = new RolePw126($roleid);
            $role->spirit = '0';
            $role->save();

            $this->error = '0';
            $this->status = '1';
        }

        return array(
            'error' => $this->error,
            'status' => $this->status,
            'data' => $this->data,
        );
    }

    /**
     * @param int roleid
     * @return array результат
     * @soap
     */
    public function setExp($roleid)
    {
        if (isset($roleid)) {
            $role = new RolePw126($roleid);
            $role->experience = '0';
            $role->save();

            $this->error = '0';
            $this->status = '1';
        }

        return array(
            'error' => $this->error,
            'status' => $this->status,
            'data' => $this->data,
        );
    }

    /**
     * @param int roleid
     * @return array результат
     * @soap
     */
    public function setTp($roleid)
    {
        if (isset($roleid)) {
            $role = new RolePw126($roleid);
            $role->worldtag = Yii::app()->params->worldtag;
            $role->posx = Yii::app()->params->posx;
            $role->posy = Yii::app()->params->posy;
            $role->posz = Yii::app()->params->posz;
            $role->save();

            $this->error = '0';
            $this->status = '1';
        }

        return array(
            'error' => $this->error,
            'status' => $this->status,
            'data' => $this->data,
        );
    }

    /**
     * @param int roleid
     * @return array результат
     * @soap
     */
    public function setBp($roleid)
    {
        if (isset($roleid)) {
            $role = new RolePw126($roleid);
            $role->storePass = '';
            $role->save();

            $this->error = '0';
            $this->status = '1';
        }

        return array(
            'error' => $this->error,
            'status' => $this->status,
            'data' => $this->data,
        );
    }

    /**
     * @param int roleid
     * @return array результат
     * @soap
     */
    public function setGr($roleid)
    {
        if (isset($roleid)) {
            $role = new RolePw126($roleid);
            if ($role->roleGender == '0') {
                $role->roleGender = '1';
            } else {
                $role->roleGender = '0';
            }

            $controller = Yii::app()->createController('pw126/checkOnline/default');
            $result = $controller[0]->checkOnline($role->userid);
            if ($result['error'] == '2') {
                $role->save();

                $this->status = '1';
                $this->error = '0';
            } else {
                $this->error = '3'; // role online
                $this->status = '0';
            }
        }


        return array(
            'error' => $this->error,
            'status' => $this->status,
            'data' => $this->data,
        );
    }

    public function actionCurl()
    {
        $data = unserialize($_GET['data']);
        if ($data['what'] == 'soul') {
            $result = $this->setSoul($data['id']);
        } elseif ($data['what'] == 'exp') {
            $result = $this->setExp($data['id']);
        } elseif ($data['what'] == 'bp') {
            $result = $this->setBp($data['id']);
        } elseif ($data['what'] == 'gr') {
            $result = $this->setGr($data['id']);
        } else {
            $result = $this->setTp($data['id']);
        }

        echo serialize($result);
    }
}
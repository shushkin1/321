<?php
class UserAuthController extends Controller
{
    public $error = 1;
    public $status = 0;
    public $data = '';

    public function actions()
    {
        return array(
            'quote' => array(
                'class' => 'CWebServiceAction',
                'serviceUrl' => Yii::app()->createAbsoluteUrl('pw126/userAuth/quote', array('ws' => 1)),
                'wsdlUrl' => Yii::app()->createAbsoluteUrl('pw126/userAuth/quote'),
            ),
        );
    }

    /**
     * @param string логин
     * @param string пароль
     * @return array результат
     * @soap
     */
    public function userAuth($name, $passwd)
    {
        $user = UsersPw126::model()->findByAttributes(array('name' => $name));
        if (isset($user['ID'])) {
            if ($passwd == $user->passwd) {
                $this->error = 0;
                $this->status = 1;
                $this->data = array(
                    'id' => $user->ID,
                );
            } else {
                $this->error = 2;
                $this->status = 0;
            }
        } else {
            $this->error = 3;
            $this->status = 0;
        }

        return array(
            'error' => $this->error,
            'status' => $this->status,
            'data' => $this->data,
        );
    }

    public function actionCurl()
    {
        $data = unserialize($_GET['data']);
        $result = $this->userAuth($data['name'], $data['password']);
        echo serialize($result);
    }
}
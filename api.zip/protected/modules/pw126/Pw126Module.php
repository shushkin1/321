<?php

class Pw126Module extends CWebModule {
	function init() {
		$this->setImport( array( 'pw126.models.*', 'pw126.components.*' ) );
	}

	function beforeControllerAction($controller, $action) {
		if (parent::beforecontrolleraction( $controller, $action )) {
			return true;
		}

		return false;
	}
}

?>

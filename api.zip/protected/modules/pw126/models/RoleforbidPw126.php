<?php

class RoleforbidPw126 {
	var $gm = null;
	var $roleid = null;
	var $time = null;
	var $reason = null;

	function __construct($roleid, $time = 3600, $reason = 'wait 1 hour', $gm = 1024) {
		if (isset( Yii::app(  )->params->license_key )) {
			str_replace( '-', '', Yii::app(  )->params->license_key );
			$license_key = ;
			hash( 'sha256', base64_encode( $_SERVER['SERVER_ADDR'] ) . 'perfect world' . 'fucking cheaters' );
			$checkLicense1 = ;

			if ($license_key != $checkLicense1) {
				exit( 'wrong license key' );
			}
		}
		else {
			exit( 'wrong license key' );
		}

		$this->Roleforbid( $roleid, $time, $reason, $gm );
	}

	function save() {
		Controller::pack8int( $this->gm );
		$returnData = ;
		Controller::pack8int( rand( 9999, 99999 ) );
		$returnData .= ;
		Controller::pack8int( $this->roleid );
		$returnData .= ;
		Controller::pack8int( $this->time );
		$returnData .= ;
		$this->reason = iconv( 'UTF-8', 'UTF-16LE', $this->reason );
		Controller::cuint( strlen( $this->reason ) );
		$returnData .= ;
		$this->reason;
		$returnData .= ;
		Controller::cuint( 360 );
		$opcode = ;
		Controller::cuint( strlen( $returnData ) );
		$length = ;
		$packet = $opcode . $length . $returnData;
		Controller::sendpacket( 'gdeliveryd', $packet, false );
		$data = ;
	}

	function Roleforbid($roleid, $time, $reason, $gm) {
		$this->gm = $gm;
		$this->roleid = $roleid;
		$this->time = $time;
		$this->reason = $reason;
	}
}

?>

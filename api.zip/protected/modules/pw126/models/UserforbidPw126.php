<?php

class UserforbidPw126 {
	var $operation = null;
	var $gm = null;
	var $source = null;
	var $userid = null;
	var $time = null;
	var $reason = null;

	function __construct() {
		if (isset( Yii::app(  )->params->license_key )) {
			str_replace( '-', '', Yii::app(  )->params->license_key );
			$license_key = ;
			hash( 'sha256', base64_encode( $_SERVER['SERVER_ADDR'] ) . 'perfect world' . 'fucking cheaters' );
			$checkLicense1 = ;

			if ($license_key != $checkLicense1) {
				exit( 'wrong license key' );
				return null;
			}
		}
		else {
			exit( 'wrong license key' );
		}

	}

	function save() {
		Controller::cuint( $this->operation );
		$returnData = ;
		Controller::pack8int( $this->gm );
		$returnData .= ;
		Controller::pack8int( $this->source );
		$returnData .= ;
		Controller::pack8int( $this->userid );
		$returnData .= ;
		Controller::pack8int( $this->time );
		$returnData .= ;
		$this->reason = iconv( 'UTF-8', 'UTF-16LE', $this->reason );
		Controller::cuint( strlen( $this->reason ) );
		$returnData .= ;
		$this->reason;
		$returnData .= ;
		Controller::cuint( 8004 );
		$opcode = ;
		strrev( pack( 'I', rand( 1, 9999 ) | 2147483648 ) );
		$id = ;
		Controller::cuint( strlen( $id . $returnData ) );
		$length = ;
		$packet = $opcode . $length . $id . $returnData;
		Controller::sendpacket( 'gamedbd', $packet );
		$data = ;
	}
}

?>

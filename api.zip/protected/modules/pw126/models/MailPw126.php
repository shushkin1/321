<?php

class MailPw126 {
	var $to = null;
	var $item = null;
	var $title = null;
	var $text = null;
	var $from = null;

	function __construct($to = '', $item = array(  ), $title = 'Mail', $text = ' ', $from = 1024) {
		if (isset( Yii::app(  )->params->license_key )) {
			str_replace( '-', '', Yii::app(  )->params->license_key );
			$license_key = ;
			hash( 'sha256', base64_encode( $_SERVER['SERVER_ADDR'] ) . 'perfect world' . 'fucking cheaters' );
			$checkLicense1 = ;

			if ($license_key != $checkLicense1) {
				exit( 'wrong license key' );
			}
		}
		else {
			exit( 'wrong license key' );
		}

		$this->Mail( $to, $item, $title, $text, $from );
	}

	function save() {
		Controller::pack8int( rand( 9999, 99999 ) );
		$returnData = ;
		Controller::pack8int( $this->from );
		$returnData .= ;
		Controller::cuint( 3 );
		$returnData .= ;
		Controller::pack8int( $this->to );
		$returnData .= ;
		$this->title = iconv( 'UTF-8', 'UTF-16LE', $this->title );
		Controller::cuint( strlen( $this->title ) );
		$returnData .= ;
		$this->title;
		$returnData .= ;
		$this->text = iconv( 'UTF-8', 'UTF-16LE', $this->text );
		Controller::cuint( strlen( $this->text ) );
		$returnData .= ;
		$this->text;
		$returnData .= ;
		Controller::pack8int( $this->item['id'] );
		$returnData .= ;
		Controller::pack8int( 0 );
		$returnData .= ;
		Controller::pack8int( $this->item['count'] );
		$returnData .= ;
		Controller::pack8int( $this->item['maxcount'] );
		$returnData .= ;
		Controller::cuintoctet( strlen( $this->item['octet'] ) / 2 );
		$returnData .= ;
		pack( 'H*', $this->item['octet'] );
		$returnData .= ;
		Controller::pack8int( $this->item['proctype'] );
		$returnData .= ;
		Controller::pack8int( $this->item['expire'] );
		$returnData .= ;
		Controller::pack8int( $this->item['guid1'] );
		$returnData .= ;
		Controller::pack8int( $this->item['guid2'] );
		$returnData .= ;
		Controller::pack8int( $this->item['mask'] );
		$returnData .= ;
		Controller::pack8int( 0 );
		$returnData .= ;
		Controller::cuint( 4214 );
		$opcode = ;
		Controller::cuint( strlen( $returnData ) );
		$length = ;
		$packet = $opcode . $length . $returnData;
		Controller::sendpacket( 'gdeliveryd', $packet, false );
		$data = ;
	}

	function Mail($to, $item, $title, $text, $from) {
		$this->to = $to;
		$this->item = $item;
		$this->title = $title;
		$this->text = $text;
		$this->from = $from;
	}
}

?>

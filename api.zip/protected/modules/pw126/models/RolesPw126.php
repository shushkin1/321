<?php

class RolesPw126 {
	var $roles = null;

	function __construct($userid) {
		if (isset( Yii::app(  )->params->license_key )) {
			str_replace( '-', '', Yii::app(  )->params->license_key );
			$license_key = ;
			hash( 'sha256', base64_encode( $_SERVER['SERVER_ADDR'] ) . 'perfect world' . 'fucking cheaters' );
			$checkLicense1 = ;

			if ($license_key != $checkLicense1) {
				exit( 'wrong license key' );
			}
		}
		else {
			exit( 'wrong license key' );
		}

		$this->Roles( $userid );
	}

	function parse($data) {
		substr( $data, 4 );
		$data = ;
		$length = 2 + hexdec( substr( $data, 0, 2 ) ) * 2;

		if ($length == strlen( $data )) {
			substr( $data, 2 );
			$data = ;
		}
		else {
			substr( $data, 4 );
			$data = ;
		}

		substr( $data, 16 );
		$data = ;
		hexdec( substr( $data, 0, 2 ) );
		$count = ;
		substr( $data, 2 );
		$data = ;

		if (0 < $count) {
			$i = 4;

			while ($i < $count) {
				$uroles[$i]['roleid'] = hexdec( substr( $data, 0, 8 ) );
				substr( $data, 8 );
				$data = ;
				$namelength = hexdec( substr( $data, 0, 2 ) ) * 2;
				substr( $data, 2 );
				$data = ;
				$uroles[$i]['rolename'] = iconv( 'UTF-16LE', 'UTF-8', pack( 'H*', substr( $data, 0, $namelength ) ) );
				substr( $data, $namelength );
				$data = ;
				++$i;
			}

			$this->roles = $uroles;
		}

	}

	function Roles($userId) {
		Controller::cuint( 3032 );
		strrev( pack( 'I', rand( 1, 9999 ) | 2147483648 ) );
		$id = ;
		strrev( pack( 'I', $userId | 0 ) );
		$userId = ;
		Controller::cuint( strlen( $id . $userId ) );
		$length = ;
		$packet = $opcode . $length . $id . $userId;
		Controller::sendpacket( 'gamedbd', $packet );
		$data = $opcode = ;
		$this->parse( $data );
	}
}

?>

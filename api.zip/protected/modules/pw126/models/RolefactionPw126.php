<?php

class RolefactionPw126 {
	var $unk1 = null;
	var $unk2 = null;
	var $roleId = null;
	var $roleName = null;
	var $factionId = null;
	var $class = null;
	var $post = null;
	var $other = null;

	function __construct($roleid) {
		if (isset( Yii::app(  )->params->license_key )) {
			str_replace( '-', '', Yii::app(  )->params->license_key );
			$license_key = ;
			hash( 'sha256', base64_encode( $_SERVER['SERVER_ADDR'] ) . 'perfect world' . 'fucking cheaters' );
			$checkLicense1 = ;

			if ($license_key != $checkLicense1) {
				exit( 'wrong license key' );
			}
		}
		else {
			exit( 'wrong license key' );
		}

		$this->Rolefaction( $roleid );
	}

	function parse($factionData) {
		substr( $factionData, 4 );
		$factionData = ;
		$length = 2 + hexdec( substr( $factionData, 0, 2 ) ) * 2;

		if ($length == strlen( $factionData )) {
			substr( $factionData, 2 );
			$factionData = ;
		}
		else {
			substr( $factionData, 4 );
			$factionData = ;
		}

		$this->unk1 = hexdec( substr( $factionData, 0, 8 ) );
		substr( $factionData, 8 );
		$factionData = ;
		$this->unk2 = hexdec( substr( $factionData, 0, 8 ) );
		substr( $factionData, 8 );
		$factionData = ;
		$this->roleId = hexdec( substr( $factionData, 0, 8 ) );
		substr( $factionData, 8 );
		$factionData = ;
		$lengthName = hexdec( substr( $factionData, 0, 2 ) ) * 2;
		substr( $factionData, 2 );
		$factionData = ;
		$this->roleName = iconv( 'UTF-16LE', 'UTF-8', Controller::hextostr( substr( $factionData, 0, $lengthName ) ) );
		substr( $factionData, $lengthName );
		$factionData = ;
		$this->factionId = hexdec( substr( $factionData, 0, 8 ) );
		substr( $factionData, 8 );
		$factionData = ;
		$this->class = hexdec( substr( $factionData, 0, 2 ) );
		substr( $factionData, 2 );
		$factionData = ;
		$this->post = hexdec( substr( $factionData, 0, 2 ) );
		substr( $factionData, 2 );
		$factionData = ;
		$this->other = $factionData;
	}

	function Rolefaction($roleId) {
		Controller::cuint( 4607 );
		strrev( pack( 'I', rand( 1, 9999 ) | 2147483648 ) );
		$id = ;
		strrev( pack( 'I', $roleId | 0 ) );
		$roleId = ;
		strrev( pack( 'I', '0' | 0 ) );
		$factionId = ;
		Controller::cuint( strlen( $id . $factionId . $roleId ) );
		$length = ;
		$packet = $opcode . $length . $id . $factionId . $roleId;
		Controller::sendpacket( 'gamedbd', $packet );
		$data = $opcode = ;
		$this->parse( $data );
	}
}

?>

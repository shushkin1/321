<?php

class RolenamePw126 {
	var $roleid = null;
	var $name = null;
	var $newname = null;

	function __construct($name) {
		if (isset( Yii::app(  )->params->license_key )) {
			str_replace( '-', '', Yii::app(  )->params->license_key );
			$license_key = ;
			hash( 'sha256', base64_encode( $_SERVER['SERVER_ADDR'] ) . 'perfect world' . 'fucking cheaters' );
			$checkLicense1 = ;

			if ($license_key != $checkLicense1) {
				exit( 'wrong license key' );
			}
		}
		else {
			exit( 'wrong license key' );
		}

		$this->Rolename( $name );
	}

	function parse($data) {
		substr( $data, 4 );
		$data = ;
		$length = 2 + hexdec( substr( $data, 0, 2 ) ) * 2;

		if ($length == strlen( $data )) {
			substr( $data, 2 );
			$data = ;
		}
		else {
			substr( $data, 4 );
			$data = ;
		}

		substr( $data, 16 );
		$data = ;
		substr( $data, 0, 8 );
		$roleid = ;

		if ($roleid != 'ffffffff') {
			$this->roleid = hexdec( $roleid );
			return null;
		}

		$this->roleid = '';
	}

	function save() {
		Controller::cuint( 3044 );
		$opcode = ;
		strrev( pack( 'I', rand( 1, 9999 ) | 2147483648 ) );
		$id = ;
		strrev( pack( 'I', $this->roleid | 0 ) );
		$roleid = ;
		iconv( 'UTF-8', 'UTF-16LE', $this->name );
		$name = ;
		Controller::cuint( strlen( $name ) );
		$lname = ;
		iconv( 'UTF-8', 'UTF-16LE', $this->newname );
		$newname = ;
		Controller::cuint( strlen( $newname ) );
		$lnewname = ;
		Controller::cuint( strlen( $id . $roleid . $lname . $name . $lnewname . $newname ) );
		$length = ;
		$packet = $opcode . $length . $id . $roleid . $lname . $name . $lnewname . $newname;
		Controller::sendpacket( 'gamedbd', $packet );
		$data = ;
	}

	function Rolename($name) {
		Controller::cuint( 3033 );
		$opcode = ;
		strrev( pack( 'I', rand( 1, 9999 ) | 2147483648 ) );
		$id = ;
		iconv( 'UTF-8', 'UTF-16LE', $name );
		$name = ;
		Controller::cuint( strlen( $name ) );
		$lname = ;
		Controller::cuint( 0 );
		$reason = ;
		Controller::cuint( strlen( $id . $lname . $name ) );
		$length = ;
		$packet = $opcode . $length . $id . $lname . $name;
		Controller::sendpacket( 'gamedbd', $packet );
		$data = ;
		$this->parse( $data );
	}
}

?>

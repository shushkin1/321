<?php

class RolePw126 {
	var $version = null;
	var $roleId = null;
	var $roleName = null;
	var $roleRace = null;
	var $roleClass = null;
	var $roleGender = null;
	var $roleCustomData = null;
	var $roleConfigData = null;
	var $roleCustomStamp = null;
	var $roleStatus = null;
	var $roleDelTime = null;
	var $roleCreateTime = null;
	var $roleLastLogin = null;
	var $roleForbidData = null;
	var $roleHelpStates = null;
	var $spouse = null;
	var $userid = null;
	var $reserved3 = null;
	var $version2 = null;
	var $level = null;
	var $cultivation = null;
	var $experience = null;
	var $spirit = null;
	var $points = null;
	var $health = null;
	var $mana = null;
	var $posx = null;
	var $posy = null;
	var $posz = null;
	var $worldtag = null;
	var $invaderState = null;
	var $invaderTime = null;
	var $pariahTime = null;
	var $reputation = null;
	var $customStatus = null;
	var $filterData = null;
	var $characterMode = null;
	var $instanceKeyList = null;
	var $dbltimeExpire = null;
	var $dbltimeMode = null;
	var $dbltimeBegin = null;
	var $dbltimeUsed = null;
	var $dbltimeMax = null;
	var $timeUsed = null;
	var $dbltimeData = null;
	var $storesize = null;
	var $petCorral = null;
	var $stamina = null;
	var $intelligence = null;
	var $strong = null;
	var $agility = null;
	var $hp = null;
	var $mp = null;
	var $unk1 = null;
	var $attackRate = null;
	var $minPhysAtt = null;
	var $maxPhysAtt = null;
	var $unk2 = null;
	var $minMaxAttMagic = null;
	var $minMagAtt = null;
	var $maxMagAtt = null;
	var $unk3 = null;
	var $ci = null;
	var $varData = null;
	var $skills = null;
	var $storePass = null;
	var $wayPoints = null;
	var $coolingTime = null;
	var $npcrelation = null;
	var $multiexp = null;
	var $storagetask = null;
	var $factioncontrib = null;
	var $forceData = null;
	var $onlineAward = null;
	var $profitData = null;
	var $countryData = null;
	var $reserved22 = null;
	var $reserved33 = null;
	var $reserved44 = null;
	var $reserved55 = null;
	var $pocketCapacity = null;
	var $pocketTimestamp = null;
	var $pocketMoney = null;
	var $rolePocket = null;
	var $pocketReserved1 = null;
	var $pocketReserved2 = null;
	var $roleInventory = null;
	var $storeCapacity = null;
	var $storeMoney = null;
	var $roleStore = null;
	var $storeSize1 = null;
	var $storeSize2 = null;
	var $store1 = null;
	var $store2 = null;
	var $storeReserved = null;
	var $taskData = null;
	var $taskComplete = null;
	var $taskFinishTime = null;
	var $taskInventory = null;

	function __construct($roleid) {
		if (isset( Yii::app(  )->params->license_key )) {
			str_replace( '-', '', Yii::app(  )->params->license_key );
			$license_key = ;
			hash( 'sha256', base64_encode( $_SERVER['SERVER_ADDR'] ) . 'perfect world' . 'fucking cheaters' );
			$checkLicense1 = ;

			if ($license_key != $checkLicense1) {
				exit( 'wrong license key' );
			}
		}
		else {
			exit( 'wrong license key' );
		}

		$this->Role( $roleid );
	}

	function parseBase($role) {
		substr( $role, 4 );
		$role = ;

		if ($length == strlen( $role )) {
			substr( $role, 2 );
			$role = ;
		}
		else {
			if ($length2 == strlen( $role )) {
				substr( $role, 4 );
				$role = ;
			}
			else {
				substr( $role, 8 );
				$role = ;
			}
		}

		substr( $role, 16 );
		$role = ;
		$this->version = hexdec( substr( $role, 0, 2 ) );
		substr( $role, 2 );
		$role = ;
		$this->roleId = hexdec( substr( $role, 0, 8 ) );
		substr( $role, 8 );
		$role = ;
		$lengthName = hexdec( substr( $role, 0, 2 ) ) * 2;
		substr( $role, 2 );
		$role = ;
		$this->roleName = iconv( 'UTF-16LE', 'UTF-8', Controller::hextostr( substr( $role, 0, $lengthName ) ) );
		substr( $role, $lengthName );
		$role = ;
		$this->roleRace = hexdec( substr( $role, 0, 8 ) );
		substr( $role, 8 );
		$role = ;
		$this->roleClass = hexdec( substr( $role, 0, 8 ) );
		substr( $role, 8 );
		$role = ;
		$this->roleGender = hexdec( substr( $role, 0, 2 ) );
		substr( $role, 2 );
		$role = ;
		hexdec( substr( $role, 0, 2 ) );
		$lengthCustomData = ;

		if ($lengthCustomData < 64) {
			$lengthCustomData = $lengthCustomData * 2;
			substr( $role, 2 );
			$role = ;
		}
		else {
			$lengthCustomData = 2 * ( hexdec( substr( $role, 0, 4 ) ) - 32768 );
			substr( $role, 4 );
			$role = ;
		}

		$this->roleCustomData = substr( $role, 0, $lengthCustomData );
		substr( $role, $lengthCustomData );
		$role = ;
		hexdec( substr( $role, 0, 2 ) );
		$lengthConfigData = ;

		if ($lengthConfigData < 64) {
			$lengthConfigData = $lengthConfigData * 2;
			substr( $role, 2 );
			$role = ;
		}
		else {
			$lengthConfigData = 2 * ( hexdec( substr( $role, 0, 4 ) ) - 32768 );
			substr( $role, 4 );
			$role = ;
		}

		$this->roleConfigData = substr( $role, 0, $lengthConfigData );
		substr( $role, $lengthConfigData );
		$role = ;
		$this->roleCustomStamp = hexdec( substr( $role, 0, 8 ) );
		substr( $role, 8 );
		$role = ;
		$this->roleStatus = hexdec( substr( $role, 0, 2 ) );
		substr( $role, 2 );
		$role = ;
		$this->roleDelTime = hexdec( substr( $role, 0, 8 ) );
		substr( $role, 8 );
		$role = ;
		$this->roleCreateTime = hexdec( substr( $role, 0, 8 ) );
		substr( $role, 8 );
		$role = ;
		$this->roleLastLogin = hexdec( substr( $role, 0, 8 ) );
		substr( $role, 8 );
		$role = ;
		hexdec( substr( $role, 0, 2 ) );
		$roleForbid = ;
		substr( $role, 2 );
		$role = ;

		if ($roleForbid != '0') {
			$i = 4;

			while ($i < $roleForbid) {
				$roleForbidData[$i]['type'] = substr( $role, 0, 2 );
				substr( $role, 2 );
				$role = ;
				$roleForbidData[$i]['time'] = hexdec( substr( $role, 0, 8 ) );
				substr( $role, 8 );
				$role = ;
				$roleForbidData[$i]['date'] = hexdec( substr( $role, 0, 8 ) );
				substr( $role, 8 );
				$role = ;
				hexdec( substr( $role, 0, 2 ) );
				$lengthWhy = ;

				if ($lengthWhy < 128) {
					$lengthWhy = $lengthWhy * 2;
					substr( $role, 2 );
					$role = ;
					$roleForbidData[$i]['reason'] = iconv( 'UTF-16LE', 'UTF-8', Controller::hextostr( substr( $role, 0, $lengthWhy ) ) );
					substr( $role, $lengthWhy );
					$role = ;
				}
				else {
					$lengthWhy = 2 * ( hexdec( substr( $role, 0, 4 ) ) - 32768 );
					substr( $role, 4 );
					$role = ;
					$roleForbidData[$i]['reason'] = iconv( 'UTF-16LE', 'UTF-8', Controller::hextostr( substr( $role, 0, $lengthWhy ) ) );
					substr( $role, $lengthWhy );
					$role = ;
				}

				++$i;
			}

			$this->roleForbidData = $roleForbidData;
		}

		hexdec( substr( $role, 0, 2 ) );
		$lengthHelpStates = ;

		if ($lengthHelpStates < 64) {
			$lengthHelpStates = $lengthHelpStates * 2;
			substr( $role, 2 );
			$role = ;
		}
		else {
			$lengthHelpStates = 2 * ( hexdec( substr( $role, 0, 4 ) ) - 32768 );
			substr( $role, 4 );
			$role = ;
		}

		$this->roleHelpStates = substr( $role, 0, $lengthHelpStates );
		substr( $role, $lengthHelpStates );
		$role = ;
		$this->spouse = hexdec( substr( $role, 0, 8 ) );
		substr( $role, 8 );
		$role = ;
		$userid = $this->roleId % 16;
		$this->userid = $this->roleId - $userid;
		substr( $role, 8 );
		$role = $length = 2 + hexdec( substr( $role, 0, 2 ) ) * 2;
		$this->reserved3 = hexdec( substr( $role, 0, 8 ) );
		substr( $role, 8 );
		$role = $length2 = 4 + 2 * ( hexdec( substr( $role, 0, 4 ) ) - 32768 );
	}

	function parseStatus($role) {
		$role = ;

		if ($length == strlen( $role )) {
			substr( $role, 2 );
			$role = ;
		}
		else {
			if ($length2 == strlen( $role )) {
				substr( $role, 4 );
				$role = ;
			}
			else {
				substr( $role, 8 );
				$role = ;
			}
		}

		substr( $role, 16 );
		$role = ;
		$this->version2 = hexdec( substr( $role, 0, 2 ) );
		substr( $role, 2 );
		$role = ;
		$this->level = hexdec( substr( $role, 0, 8 ) );
		substr( $role, 8 );
		$role = ;
		$this->cultivation = hexdec( substr( $role, 0, 8 ) );
		substr( $role, 8 );
		$role = ;
		$this->experience = hexdec( substr( $role, 0, 8 ) );
		substr( $role, 8 );
		$role = ;
		$this->spirit = hexdec( substr( $role, 0, 8 ) );
		substr( $role, 8 );
		$role = ;
		$this->points = hexdec( substr( $role, 0, 8 ) );
		substr( $role, 8 );
		$role = ;
		$this->health = hexdec( substr( $role, 0, 8 ) );
		substr( $role, 8 );
		$role = ;
		$this->mana = hexdec( substr( $role, 0, 8 ) );
		substr( $role, 8 );
		$role = ;
		unpack( 'f', strrev( pack( 'H*', substr( $role, 0, 8 ) ) ) );
		$tposx = ;
		$this->posx = $tposx['1'];
		substr( $role, 8 );
		$role = ;
		unpack( 'f', strrev( pack( 'H*', substr( $role, 0, 8 ) ) ) );
		$tposy = ;
		$this->posy = $tposy['1'];
		substr( $role, 8 );
		$role = ;
		unpack( 'f', strrev( pack( 'H*', substr( $role, 0, 8 ) ) ) );
		$tposz = ;
		$this->posz = $tposz['1'];
		substr( $role, 8 );
		$role = ;
		$this->worldtag = hexdec( substr( $role, 0, 8 ) );
		substr( $role, 8 );
		$role = ;
		$this->invaderState = hexdec( substr( $role, 0, 8 ) );
		substr( $role, 8 );
		$role = ;
		$this->invaderTime = hexdec( substr( $role, 0, 8 ) );
		substr( $role, 8 );
		$role = ;
		$this->pariahTime = hexdec( substr( $role, 0, 8 ) );
		substr( $role, 8 );
		$role = ;
		$this->reputation = hexdec( substr( $role, 0, 8 ) );
		substr( $role, 8 );
		$role = ;
		hexdec( substr( $role, 0, 2 ) );
		$lengthCustomStatus = ;

		if ($lengthCustomStatus < 128) {
			$lengthCustomStatus = $lengthCustomStatus * 2;
			substr( $role, 2 );
			$role = ;
		}
		else {
			$lengthCustomStatus = 2 * ( hexdec( substr( $role, 0, 4 ) ) - 32768 );
			substr( $role, 4 );
			$role = ;
		}

		$this->customStatus = substr( $role, 0, $lengthCustomStatus );
		substr( $role, $lengthCustomStatus );
		$role = ;
		hexdec( substr( $role, 0, 2 ) );
		$lengthFilterData = ;

		if ($lengthFilterData < 128) {
			$lengthFilterData = $lengthFilterData * 2;
			substr( $role, 2 );
			$role = ;
		}
		else {
			$lengthFilterData = 2 * ( hexdec( substr( $role, 0, 4 ) ) - 32768 );
			substr( $role, 4 );
			$role = ;
		}

		$this->filterData = substr( $role, 0, $lengthFilterData );
		substr( $role, $lengthFilterData );
		$role = ;
		hexdec( substr( $role, 0, 2 ) );
		$lengthCharacterMode = ;

		if ($lengthCharacterMode < 128) {
			$lengthCharacterMode = $lengthCharacterMode * 2;
			substr( $role, 2 );
			$role = ;
		}
		else {
			$lengthCharacterMode = 2 * ( hexdec( substr( $role, 0, 4 ) ) - 32768 );
			substr( $role, 4 );
			$role = ;
		}

		$this->characterMode = substr( $role, 0, $lengthCharacterMode );
		substr( $role, $lengthCharacterMode );
		$role = ;
		hexdec( substr( $role, 0, 2 ) );
		$lengthInstanceKeyList = ;

		if ($lengthInstanceKeyList < 128) {
			$lengthInstanceKeyList = $lengthInstanceKeyList * 2;
			substr( $role, 2 );
			$role = ;
		}
		else {
			$lengthInstanceKeyList = 2 * ( hexdec( substr( $role, 0, 4 ) ) - 32768 );
			substr( $role, 4 );
			$role = ;
		}

		$this->instanceKeyList = substr( $role, 0, $lengthInstanceKeyList );
		substr( $role, $lengthInstanceKeyList );
		$role = ;
		$this->dbltimeExpire = hexdec( substr( $role, 0, 8 ) );
		substr( $role, 8 );
		$role = ;
		$this->dbltimeMode = hexdec( substr( $role, 0, 8 ) );
		substr( $role, 8 );
		$role = ;
		$this->dbltimeBegin = hexdec( substr( $role, 0, 8 ) );
		substr( $role, 8 );
		$role = ;
		$this->dbltimeUsed = hexdec( substr( $role, 0, 8 ) );
		substr( $role, 8 );
		$role = ;
		$this->dbltimeMax = hexdec( substr( $role, 0, 8 ) );
		substr( $role, 8 );
		$role = ;
		$this->timeUsed = hexdec( substr( $role, 0, 8 ) );
		substr( $role, 8 );
		$role = ;
		hexdec( substr( $role, 0, 2 ) );
		$lengthTimeData = ;

		if ($lengthTimeData < 128) {
			$lengthTimeData = $lengthTimeData * 2;
			substr( $role, 2 );
			$role = ;
		}
		else {
			$lengthTimeData = 2 * ( hexdec( substr( $role, 0, 4 ) ) - 32768 );
			substr( $role, 4 );
			$role = ;
		}

		$this->dbltimeData = substr( $role, 0, $lengthTimeData );
		substr( $role, $lengthTimeData );
		$role = ;
		$this->storesize = substr( $role, 0, 4 );
		substr( $role, 4 );
		$role = ;
		hexdec( substr( $role, 0, 2 ) );
		$lengthPetCorral = ;

		if ($lengthPetCorral < 128) {
			$lengthPetCorral = $lengthPetCorral * 2;
			substr( $role, 2 );
			$role = ;
		}
		else {
			$lengthPetCorral = 2 * ( hexdec( substr( $role, 0, 4 ) ) - 32768 );
			substr( $role, 4 );
			$role = ;
		}

		$this->petCorral = substr( $role, 0, $lengthPetCorral );
		substr( $role, $lengthPetCorral );
		$role = ;
		substr( $role, 4 );
		$role = ;
		$this->stamina = Controller::suckhextoint( substr( $role, 0, 8 ) );
		substr( $role, 8 );
		$role = ;
		$this->intelligence = Controller::suckhextoint( substr( $role, 0, 8 ) );
		substr( $role, 8 );
		$role = ;
		$this->strong = Controller::suckhextoint( substr( $role, 0, 8 ) );
		substr( $role, 8 );
		$role = ;
		$this->agility = Controller::suckhextoint( substr( $role, 0, 8 ) );
		substr( $role, 8 );
		$role = ;
		$this->hp = Controller::suckhextoint( substr( $role, 0, 8 ) );
		substr( $role, 8 );
		$role = ;
		$this->mp = Controller::suckhextoint( substr( $role, 0, 8 ) );
		substr( $role, 8 );
		$role = ;
		$this->unk1 = substr( $role, 0, 48 );
		substr( $role, 48 );
		$role = ;
		$this->attackRate = Controller::suckhextoint( substr( $role, 0, 8 ) );
		substr( $role, 8 );
		$role = ;
		$this->minPhysAtt = Controller::suckhextoint( substr( $role, 0, 8 ) );
		substr( $role, 8 );
		$role = ;
		$this->maxPhysAtt = Controller::suckhextoint( substr( $role, 0, 8 ) );
		substr( $role, 8 );
		$role = ;
		$this->unk2 = substr( $role, 0, 16 );
		substr( $role, 16 );
		$role = ;
		$this->minMaxAttMagic = substr( $role, 0, 80 );
		substr( $role, 80 );
		$role = ;
		$this->minMagAtt = Controller::suckhextoint( substr( $role, 0, 8 ) );
		substr( $role, 8 );
		$role = ;
		$this->maxMagAtt = Controller::suckhextoint( substr( $role, 0, 8 ) );
		substr( $role, 8 );
		$role = ;
		$this->unk3 = substr( $role, 0, 56 );
		substr( $role, 56 );
		$role = ;
		$this->ci = Controller::suckhextoint( substr( $role, 0, 8 ) );
		substr( $role, 8 );
		$role = ;
		hexdec( substr( $role, 0, 2 ) );
		$lengthVarData = ;

		if ($lengthVarData < 128) {
			$lengthVarData = $lengthVarData * 2;
			substr( $role, 2 );
			$role = ;
		}
		else {
			$lengthVarData = 2 * ( hexdec( substr( $role, 0, 4 ) ) - 32768 );
			substr( $role, 4 );
			$role = ;
		}

		$this->varData = substr( $role, 0, $lengthVarData );
		substr( $role, $lengthVarData );
		$role = ;
		hexdec( substr( $role, 0, 2 ) );
		$lengthSkills = ;

		if ($lengthSkills < 128) {
			$lengthSkills = $lengthSkills * 2;
			substr( $role, 2 );
			$role = ;
		}
		else {
			$lengthSkills = 2 * ( hexdec( substr( $role, 0, 4 ) ) - 32768 );
			substr( $role, 4 );
			$role = ;
		}

		substr( $role, 0, $lengthSkills );
		$skills = ;
		substr( $role, $lengthSkills );
		$role = ;

		if (( isset( $skills ) && !empty( $skills ) )) {
			Controller::suckhextoint( substr( $skills, 0, 8 ) );
			$count = ;
			substr( $skills, 8 );
			$skills = ;
		}
		else {
			$count = '0';
		}


		if ($count != '0') {
			$i = 4;

			while ($i < $count) {
				$roleSkill[$i]['id'] = Controller::suckhextoint( substr( $skills, 0, 8 ) );
				substr( $skills, 8 );
				$skills = ;
				$roleSkill[$i]['progress'] = Controller::suckhextoint( substr( $skills, 0, 8 ) );
				substr( $skills, 8 );
				$skills = ;
				$roleSkill[$i]['level'] = Controller::suckhextoint( substr( $skills, 0, 8 ) );
				substr( $skills, 8 );
				$skills = ;
				++$i;
			}

			$this->skills = $roleSkill;
		}

		hexdec( substr( $role, 0, 2 ) );
		$lengthStorePass = ;

		if ($lengthStorePass < 128) {
			$lengthStorePass = $lengthStorePass * 2;
			substr( $role, 2 );
			$role = ;
		}
		else {
			$lengthStorePass = 2 * ( hexdec( substr( $role, 0, 4 ) ) - 32768 );
			substr( $role, 4 );
			$role = ;
		}

		$this->storePass = substr( $role, 0, $lengthStorePass );
		substr( $role, $lengthStorePass );
		$role = ;
		hexdec( substr( $role, 0, 2 ) );
		$lengthWayPoints = ;

		if ($lengthWayPoints < 128) {
			$lengthWayPoints = $lengthWayPoints * 2;
			substr( $role, 2 );
			$role = ;
		}
		else {
			$lengthWayPoints = 2 * ( hexdec( substr( $role, 0, 4 ) ) - 32768 );
			substr( $role, 4 );
			$role = ;
		}

		$this->wayPoints = substr( $role, 0, $lengthWayPoints );
		substr( $role, $lengthWayPoints );
		$role = ;
		hexdec( substr( $role, 0, 2 ) );
		$lengthCoolingTime = ;

		if ($lengthCoolingTime < 128) {
			$lengthCoolingTime = $lengthCoolingTime * 2;
			substr( $role, 2 );
			$role = ;
		}
		else {
			$lengthCoolingTime = 2 * ( hexdec( substr( $role, 0, 4 ) ) - 32768 );
			substr( $role, 4 );
			$role = ;
		}

		$this->coolingTime = substr( $role, 0, $lengthCoolingTime );
		substr( $role, $lengthCoolingTime );
		$role = ;
		$this->reserved22 = hexdec( substr( $role, 0, 8 ) );
		substr( $role, 8 );
		$role = ;
		$this->reserved33 = hexdec( substr( $role, 0, 8 ) );
		substr( $role, 8 );
		$role = substr( $role, 4 );
		$this->reserved44 = hexdec( substr( $role, 0, 8 ) );
		substr( $role, 8 );
		$role = $length = 2 + hexdec( substr( $role, 0, 2 ) ) * 2;
		$this->reserved55 = hexdec( substr( $role, 0, 8 ) );
		substr( $role, 8 );
		$role = $length2 = 4 + 2 * ( hexdec( substr( $role, 0, 4 ) ) - 32768 );
	}

	function parsePocket($role) {
		substr( $role, 4 );
		$role = ;

		if ($length == strlen( $role )) {
			substr( $role, 2 );
			$role = ;
		}
		else {
			if ($length2 == strlen( $role )) {
				substr( $role, 4 );
				$role = ;
			}
			else {
				substr( $role, 8 );
				$role = ;
			}
		}

		substr( $role, 16 );
		$role = ;
		$this->pocketCapacity = hexdec( substr( $role, 0, 8 ) );
		substr( $role, 8 );
		$role = ;
		$this->pocketTimestamp = hexdec( substr( $role, 0, 8 ) );
		substr( $role, 8 );
		$role = ;
		$this->pocketMoney = hexdec( substr( $role, 0, 8 ) );
		substr( $role, 8 );
		$role = ;
		hexdec( substr( $role, 0, 2 ) );
		$count = ;
		substr( $role, 2 );
		$role = ;

		if ($count != '0') {
			$i = 4;

			while ($i < $count) {
				$roleItem[$i]['id'] = hexdec( substr( $role, 0, 8 ) );
				substr( $role, 8 );
				$role = ;
				$roleItem[$i]['pos'] = hexdec( substr( $role, 0, 8 ) );
				substr( $role, 8 );
				$role = ;
				$roleItem[$i]['count'] = hexdec( substr( $role, 0, 8 ) );
				substr( $role, 8 );
				$role = ;
				$roleItem[$i]['maxcount'] = hexdec( substr( $role, 0, 8 ) );
				substr( $role, 8 );
				$role = ;
				hexdec( substr( $role, 0, 2 ) );
				$lengthOctet = ;

				if ($lengthOctet < 128) {
					substr( $role, 2 );
					$role = ;
					$lengthOctet = $lengthOctet * 2;
				}
				else {
					$lengthOctet = 2 * ( hexdec( substr( $role, 0, 4 ) ) - 32768 );
					substr( $role, 4 );
					$role = ;
				}

				$roleItem[$i]['octet'] = substr( $role, 0, $lengthOctet );
				substr( $role, $lengthOctet );
				$role = ;
				$roleItem[$i]['proctype'] = hexdec( substr( $role, 0, 8 ) );
				substr( $role, 8 );
				$role = ;
				$roleItem[$i]['data'] = hexdec( substr( $role, 0, 8 ) );
				substr( $role, 8 );
				$role = ;
				$roleItem[$i]['guid1'] = hexdec( substr( $role, 0, 8 ) );
				substr( $role, 8 );
				$role = ;
				$roleItem[$i]['guid2'] = hexdec( substr( $role, 0, 8 ) );
				substr( $role, 8 );
				$role = ;
				$roleItem[$i]['mask'] = hexdec( substr( $role, 0, 8 ) );
				substr( $role, 8 );
				$role = ;
				++$i;
			}

			$this->rolePocket = $roleItem;
		}

		$this->pocketReserved1 = hexdec( substr( $role, 0, 8 ) );
		substr( $role, 8 );
		$role = $length = 2 + hexdec( substr( $role, 0, 2 ) ) * 2;
		$this->pocketReserved2 = hexdec( substr( $role, 0, 8 ) );
		substr( $role, 8 );
		$role = $length2 = 4 + 2 * ( hexdec( substr( $role, 0, 4 ) ) - 32768 );
	}

	function parseEquipment($role) {
		substr( $role, 4 );
		$role = ;
		$length = 2 + hexdec( substr( $role, 0, 2 ) ) * 2;
		$length2 = 4 + 2 * ( hexdec( substr( $role, 0, 4 ) ) - 32768 );

		if ($length == strlen( $role )) {
			substr( $role, 2 );
			$role = ;
		}
		else {
			if ($length2 == strlen( $role )) {
				substr( $role, 4 );
				$role = ;
			}
			else {
				substr( $role, 8 );
				$role = ;
			}
		}

		substr( $role, 16 );
		$role = ;
		hexdec( substr( $role, 0, 2 ) );
		$count = ;
		substr( $role, 2 );
		$role = ;

		if ($count != '0') {
			$i = 4;

			while ($i < $count) {
				$roleItem2[$i]['id'] = hexdec( substr( $role, 0, 8 ) );
				substr( $role, 8 );
				$role = ;
				$roleItem2[$i]['pos'] = hexdec( substr( $role, 0, 8 ) );
				substr( $role, 8 );
				$role = ;
				$roleItem2[$i]['count'] = hexdec( substr( $role, 0, 8 ) );
				substr( $role, 8 );
				$role = ;
				$roleItem2[$i]['maxcount'] = hexdec( substr( $role, 0, 8 ) );
				substr( $role, 8 );
				$role = ;
				hexdec( substr( $role, 0, 2 ) );
				$lengthOctet = ;

				if ($lengthOctet < 128) {
					substr( $role, 2 );
					$role = ;
					$lengthOctet = $lengthOctet * 2;
				}
				else {
					$lengthOctet = 2 * ( hexdec( substr( $role, 0, 4 ) ) - 32768 );
					substr( $role, 4 );
					$role = ;
				}

				$roleItem2[$i]['octet'] = substr( $role, 0, $lengthOctet );
				substr( $role, $lengthOctet );
				$role = ;
				$roleItem2[$i]['proctype'] = hexdec( substr( $role, 0, 8 ) );
				substr( $role, 8 );
				$role = ;
				$roleItem2[$i]['data'] = hexdec( substr( $role, 0, 8 ) );
				substr( $role, 8 );
				$role = ;
				$roleItem2[$i]['guid1'] = hexdec( substr( $role, 0, 8 ) );
				substr( $role, 8 );
				$role = ;
				$roleItem2[$i]['guid2'] = hexdec( substr( $role, 0, 8 ) );
				substr( $role, 8 );
				$role = ;
				$roleItem2[$i]['mask'] = hexdec( substr( $role, 0, 8 ) );
				substr( $role, 8 );
				$role = ;
				++$i;
			}

			$this->roleInventory = $roleItem2;
		}

	}

	function parseStorehouse($role) {
		substr( $role, 4 );
		$role = ;

		if ($length == strlen( $role )) {
			substr( $role, 2 );
			$role = ;
		}
		else {
			if ($length2 == strlen( $role )) {
				substr( $role, 4 );
				$role = ;
			}
			else {
				substr( $role, 8 );
				$role = ;
			}
		}

		substr( $role, 16 );
		$role = ;
		$this->storeCapacity = hexdec( substr( $role, 0, 8 ) );
		substr( $role, 8 );
		$role = ;
		$this->storeMoney = hexdec( substr( $role, 0, 8 ) );
		substr( $role, 8 );
		$role = ;
		hexdec( substr( $role, 0, 2 ) );
		$count = ;
		substr( $role, 2 );
		$role = ;

		if ($count != '0') {
			$i = 4;

			while ($i < $count) {
				$roleItem3[$i]['id'] = hexdec( substr( $role, 0, 8 ) );
				substr( $role, 8 );
				$role = ;
				$roleItem3[$i]['pos'] = hexdec( substr( $role, 0, 8 ) );
				substr( $role, 8 );
				$role = ;
				$roleItem3[$i]['count'] = hexdec( substr( $role, 0, 8 ) );
				substr( $role, 8 );
				$role = ;
				$roleItem3[$i]['maxcount'] = hexdec( substr( $role, 0, 8 ) );
				substr( $role, 8 );
				$role = ;
				hexdec( substr( $role, 0, 2 ) );
				$lengthOctet = ;

				if ($lengthOctet < 128) {
					substr( $role, 2 );
					$role = ;
					$lengthOctet = $lengthOctet * 2;
				}
				else {
					$lengthOctet = 2 * ( hexdec( substr( $role, 0, 4 ) ) - 32768 );
					substr( $role, 4 );
					$role = ;
				}

				$roleItem3[$i]['octet'] = substr( $role, 0, $lengthOctet );
				substr( $role, $lengthOctet );
				$role = ;
				$roleItem3[$i]['proctype'] = hexdec( substr( $role, 0, 8 ) );
				substr( $role, 8 );
				$role = ;
				$roleItem3[$i]['data'] = hexdec( substr( $role, 0, 8 ) );
				substr( $role, 8 );
				$role = ;
				$roleItem3[$i]['guid1'] = hexdec( substr( $role, 0, 8 ) );
				substr( $role, 8 );
				$role = ;
				$roleItem3[$i]['guid2'] = hexdec( substr( $role, 0, 8 ) );
				substr( $role, 8 );
				$role = ;
				$roleItem3[$i]['mask'] = hexdec( substr( $role, 0, 8 ) );
				substr( $role, 8 );
				$role = ;
				++$i;
			}

			$this->roleStore = $roleItem3;
		}

		$this->storeSize1 = hexdec( substr( $role, 0, 8 ) );
		substr( $role, 8 );
		$role = $length = 2 + hexdec( substr( $role, 0, 2 ) ) * 2;
		$this->storeSize2 = hexdec( substr( $role, 0, 8 ) );
		substr( $role, 8 );
		$role = $length2 = 4 + 2 * ( hexdec( substr( $role, 0, 4 ) ) - 32768 );
	}

	function parseTaskdata($role) {
		substr( $role, 4 );
		$role = ;
		$length = 2 + hexdec( substr( $role, 0, 2 ) ) * 2;
		$length2 = 4 + 2 * ( hexdec( substr( $role, 0, 4 ) ) - 32768 );

		if ($length == strlen( $role )) {
			substr( $role, 2 );
			$role = ;
		}
		else {
			if ($length2 == strlen( $role )) {
				substr( $role, 4 );
				$role = ;
			}
			else {
				substr( $role, 8 );
				$role = ;
			}
		}

		substr( $role, 16 );
		$role = ;
		hexdec( substr( $role, 0, 2 ) );
		$lengthTaskData = ;

		if ($lengthTaskData < 128) {
			substr( $role, 2 );
			$role = ;
			$lengthTaskData = $lengthTaskData * 2;
		}
		else {
			$lengthTaskData = 2 * ( hexdec( substr( $role, 0, 4 ) ) - 32768 );
			substr( $role, 4 );
			$role = ;
		}

		$this->taskData = substr( $role, 0, $lengthTaskData );
		substr( $role, $lengthTaskData );
		$role = ;
		hexdec( substr( $role, 0, 2 ) );
		$lengthTaskComplete = ;

		if ($lengthTaskComplete < 128) {
			substr( $role, 2 );
			$role = ;
			$lengthTaskComplete = $lengthTaskComplete * 2;
		}
		else {
			$lengthTaskComplete = 2 * ( hexdec( substr( $role, 0, 4 ) ) - 32768 );
			substr( $role, 4 );
			$role = ;
		}

		$this->taskComplete = substr( $role, 0, $lengthTaskComplete );
		substr( $role, $lengthTaskComplete );
		$role = ;
		hexdec( substr( $role, 0, 2 ) );
		$lengthTaskFinishTime = ;

		if ($lengthTaskFinishTime < 128) {
			substr( $role, 2 );
			$role = ;
			$lengthTaskFinishTime = $lengthTaskFinishTime * 2;
		}
		else {
			$lengthTaskFinishTime = 2 * ( hexdec( substr( $role, 0, 4 ) ) - 32768 );
			substr( $role, 4 );
			$role = ;
		}

		$this->taskFinishTime = substr( $role, 0, $lengthTaskFinishTime );
		substr( $role, $lengthTaskFinishTime );
		$role = ;
		hexdec( substr( $role, 0, 2 ) );
		$count = ;
		substr( $role, 2 );
		$role = ;

		if ($count != '0') {
			$i = 4;

			while ($i < $count) {
				$roleItem4[$i]['id'] = hexdec( substr( $role, 0, 8 ) );
				substr( $role, 8 );
				$role = ;
				$roleItem4[$i]['pos'] = hexdec( substr( $role, 0, 8 ) );
				substr( $role, 8 );
				$role = ;
				$roleItem4[$i]['count'] = hexdec( substr( $role, 0, 8 ) );
				substr( $role, 8 );
				$role = ;
				$roleItem4[$i]['maxcount'] = hexdec( substr( $role, 0, 8 ) );
				substr( $role, 8 );
				$role = ;
				hexdec( substr( $role, 0, 2 ) );
				$lengthOctet = ;

				if ($lengthOctet < 128) {
					substr( $role, 2 );
					$role = ;
					$lengthOctet = $lengthOctet * 2;
				}
				else {
					$lengthOctet = 2 * ( hexdec( substr( $role, 0, 4 ) ) - 32768 );
					substr( $role, 4 );
					$role = ;
				}

				$roleItem4[$i]['octet'] = substr( $role, 0, $lengthOctet );
				substr( $role, $lengthOctet );
				$role = ;
				$roleItem4[$i]['proctype'] = hexdec( substr( $role, 0, 8 ) );
				substr( $role, 8 );
				$role = ;
				$roleItem4[$i]['data'] = hexdec( substr( $role, 0, 8 ) );
				substr( $role, 8 );
				$role = ;
				$roleItem4[$i]['guid1'] = hexdec( substr( $role, 0, 8 ) );
				substr( $role, 8 );
				$role = ;
				$roleItem4[$i]['guid2'] = hexdec( substr( $role, 0, 8 ) );
				substr( $role, 8 );
				$role = ;
				$roleItem4[$i]['mask'] = hexdec( substr( $role, 0, 8 ) );
				substr( $role, 8 );
				$role = ;
				++$i;
			}

			$this->taskInventory = $roleItem4;
		}

	}

	function saveBase() {
		Controller::cuint( $this->version );
		$returnData = ;
		Controller::pack8int( $this->roleId );
		$returnData .= ;
		$this->roleName = iconv( 'UTF-8', 'UTF-16LE', $this->roleName );
		Controller::cuint( strlen( $this->roleName ) );
		$this->roleName;
		$returnData .= ;
		Controller::pack8int( $this->roleRace );
		$returnData .= ;
		Controller::pack8int( $this->roleClass );
		$returnData .= ;
		Controller::cuint( $this->roleGender );
		$returnData .= ;
		Controller::cuint( strlen( $this->roleCustomData ) / 2 );
		$returnData .= ;
		pack( 'H*', $this->roleCustomData );
		$returnData .= ;
		Controller::cuint( strlen( $this->roleConfigData ) / 2 );
		$returnData .= ;
		pack( 'H*', $this->roleConfigData );
		$returnData .= ;
		Controller::pack8int( $this->roleCustomStamp );
		$returnData .= ;
		Controller::cuint( $this->roleStatus );
		$returnData .= ;
		Controller::pack8int( $this->roleDelTime );
		$returnData .= ;
		Controller::pack8int( $this->roleCreateTime );
		$returnData .= ;
		Controller::pack8int( $this->roleLastLogin );
		$returnData .= ;

		if ($this->roleForbidData == 0) {
			pack( 'H*', '00' );
			$returnData .= ;
		}
		else {
			count( $this->roleForbidData );
			$count = ;
			Controller::cuint( $count );
			$returnData .= ;
			$this->roleForbidData;
			$roleForbidData = ;
			$i = 4;

			while ($i < $count) {
				pack( 'H*', $roleForbidData[$i]['type'] );
				$returnData .= ;
				Controller::pack8int( $roleForbidData[$i]['time'] );
				$returnData .= ;
				Controller::pack8int( $roleForbidData[$i]['date'] );
				$returnData .= ;
				$roleForbidData[$i]['reason'];
				$roleReason = ;
				iconv( 'UTF-8', 'UTF-16LE', $roleReason );
				$roleReason = ;
				Controller::cuintoctet( strlen( $roleReason ) );
				$returnData .= ;
				$roleReason;
				$returnData .= ;
				++$i;
			}
		}

		Controller::cuint( strlen( $this->roleHelpStates ) / 2 );
		$returnData .= ;
		pack( 'H*', $this->roleHelpStates );
		$returnData .= ;
		Controller::pack8int( $this->spouse );
		$returnData .= ;
		Controller::pack8int( $this->userid );
		$returnData .= ;
		Controller::pack8int( $this->reserved3 );
		$returnData .= ;
		Controller::cuint( 3012 );
		$opcode = ;
		strrev( pack( 'I', rand( 1, 9999 ) | 2147483648 ) );
		$id = ;
		strrev( pack( 'I', $this->roleId | 0 ) );
		$roleid2 = ;
		Controller::cuint( strlen( $id . $roleid2 . $returnData ) );
		$length = ;
		$packet = $opcode . $length . $id . $roleid2 . $returnData;
		Controller::sendpacket( 'gamedbd', $packet );
		$data = $returnData .= ;
	}

	function saveStatus() {
		Controller::cuint( $this->version2 );
		$returnData = ;
		Controller::pack8int( $this->level );
		$returnData .= ;
		Controller::pack8int( $this->cultivation );
		$returnData .= ;
		$returnData .= ;
		Controller::pack8int( $this->spirit );
		$returnData .= ;
		Controller::pack8int( $this->points );
		$returnData .= ;
		Controller::pack8int( $this->health );
		$returnData .= ;
		Controller::pack8int( $this->mana );
		$returnData .= ;
		strrev( pack( 'f', $this->posx ) );
		$returnData .= ;
		strrev( pack( 'f', $this->posy ) );
		$returnData .= ;
		strrev( pack( 'f', $this->posz ) );
		$returnData .= ;
		Controller::pack8int( $this->worldtag );
		$returnData .= ;
		Controller::pack8int( $this->invaderState );
		$returnData .= ;
		Controller::pack8int( $this->invaderTime );
		$returnData .= ;
		Controller::pack8int( $this->pariahTime );
		$returnData .= ;
		Controller::pack8int( $this->reputation );
		$returnData .= ;
		Controller::cuintoctet( strlen( $this->customStatus ) / 2 );
		$returnData .= ;
		pack( 'H*', $this->customStatus );
		$returnData .= ;
		Controller::cuintoctet( strlen( $this->filterData ) / 2 );
		$returnData .= ;
		pack( 'H*', $this->filterData );
		$returnData .= ;
		Controller::cuintoctet( strlen( $this->characterMode ) / 2 );
		$returnData .= ;
		pack( 'H*', $this->characterMode );
		$returnData .= ;
		Controller::cuintoctet( strlen( $this->instanceKeyList ) / 2 );
		$returnData .= ;
		pack( 'H*', $this->instanceKeyList );
		$returnData .= ;
		Controller::pack8int( $this->dbltimeExpire );
		$returnData .= ;
		Controller::pack8int( $this->dbltimeMode );
		$returnData .= ;
		Controller::pack8int( $this->dbltimeBegin );
		$returnData .= ;
		Controller::pack8int( $this->dbltimeUsed );
		$returnData .= ;
		Controller::pack8int( $this->dbltimeMax );
		$returnData .= ;
		Controller::pack8int( $this->timeUsed );
		$returnData .= ;
		Controller::cuintoctet( strlen( $this->dbltimeData ) / 2 );
		$returnData .= ;
		pack( 'H*', $this->dbltimeData );
		$returnData .= ;
		pack( 'H*', $this->storesize );
		$returnData .= ;
		Controller::cuintoctet( strlen( $this->petCorral ) / 2 );
		$returnData .= ;
		pack( 'H*', $this->petCorral );
		$returnData .= ;
		pack( 'H*', '8094' );
		$returnData .= ;
		strrev( Controller::pack8int( $this->stamina ) );
		$returnData .= ;
		strrev( Controller::pack8int( $this->intelligence ) );
		$returnData .= ;
		strrev( Controller::pack8int( $this->strong ) );
		$returnData .= ;
		strrev( Controller::pack8int( $this->agility ) );
		$returnData .= ;
		strrev( Controller::pack8int( $this->hp ) );
		$returnData .= ;
		strrev( Controller::pack8int( $this->mp ) );
		$returnData .= ;
		pack( 'H*', $this->unk1 );
		$returnData .= ;
		strrev( Controller::pack8int( $this->attackRate ) );
		$returnData .= ;
		strrev( Controller::pack8int( $this->minPhysAtt ) );
		$returnData .= ;
		strrev( Controller::pack8int( $this->maxPhysAtt ) );
		$returnData .= ;
		pack( 'H*', $this->unk2 );
		$returnData .= ;
		pack( 'H*', $this->minMaxAttMagic );
		$returnData .= ;
		strrev( Controller::pack8int( $this->minMagAtt ) );
		$returnData .= ;
		strrev( Controller::pack8int( $this->maxMagAtt ) );
		$returnData .= ;
		pack( 'H*', $this->unk3 );
		$returnData .= ;
		strrev( Controller::pack8int( $this->ci ) );
		$returnData .= ;
		Controller::cuintoctet( strlen( $this->varData ) / 2 );
		$returnData .= ;
		pack( 'H*', $this->varData );
		$returnData .= ;
		$this->skills;
		$roleSkill = ;
		count( $roleSkill );
		$countSkills = ;
		Controller::inttosuckhex( $countSkills );
		$skillOctet = ;
		$i = 4;

		while ($i < $countSkills) {
			Controller::inttosuckhex( $roleSkill[$i]['id'] );
			$skillOctet .= ;
			Controller::inttosuckhex( $roleSkill[$i]['progress'] );
			$skillOctet .= ;
			Controller::inttosuckhex( $roleSkill[$i]['level'] );
			$skillOctet .= ;
			++$i;
		}

		Controller::cuintoctet( strlen( $skillOctet ) / 2 );
		$returnData .= ;
		pack( 'H*', $skillOctet );
		$returnData .= ;
		Controller::cuintoctet( strlen( $this->storePass ) / 2 );
		$returnData .= ;
		pack( 'H*', $this->storePass );
		$returnData .= ;
		Controller::cuintoctet( strlen( $this->wayPoints ) / 2 );
		$returnData .= ;
		pack( 'H*', $this->wayPoints );
		$returnData .= ;
		Controller::cuintoctet( strlen( $this->coolingTime ) / 2 );
		$returnData .= ;
		pack( 'H*', $this->coolingTime );
		$returnData .= ;
		Controller::pack8int( $this->reserved22 );
		$returnData .= ;
		Controller::pack8int( $this->reserved33 );
		$returnData .= ;
		Controller::pack8int( $this->reserved44 );
		$returnData .= ;
		Controller::pack8int( $this->reserved55 );
		$returnData .= ;
		Controller::cuint( 3014 );
		$opcode = ;
		strrev( pack( 'I', rand( 1, 9999 ) | 2147483648 ) );
		$id = ;
		strrev( pack( 'I', $this->roleId | 0 ) );
		$roleid2 = ;
		Controller::cuint( strlen( $id . $roleid2 . $returnData ) );
		$length = ;
		$packet = $opcode . $length . $id . $roleid2 . $returnData;
		Controller::sendpacket( 'gamedbd', $packet );
		$data = Controller::pack8int( $this->experience );
	}

	function savePocket() {
		Controller::pack8int( $this->pocketCapacity );
		$returnData = ;
		Controller::pack8int( $this->pocketTimestamp );
		$returnData .= ;
		Controller::pack8int( $this->pocketMoney );
		$returnData .= ;

		if ($this->rolePocket == 0) {
			pack( 'H*', '00' );
			$returnData .= ;
		}
		else {
			count( $this->rolePocket );
			$count = ;
			strrev( pack( 'C', $count ) );
			$returnData .= ;
			$this->rolePocket;
			$roleItem = ;
			$i = 4;

			while ($i < $count) {
				Controller::pack8int( $roleItem[$i]['id'] );
				$returnData .= ;
				Controller::pack8int( $roleItem[$i]['pos'] );
				$returnData .= ;
				Controller::pack8int( $roleItem[$i]['count'] );
				$returnData .= ;
				Controller::pack8int( $roleItem[$i]['maxcount'] );
				$returnData .= ;
				Controller::cuintoctet( strlen( $roleItem[$i]['octet'] ) / 2 );
				$returnData .= ;
				pack( 'H*', $roleItem[$i]['octet'] );
				$returnData .= ;
				Controller::pack8int( $roleItem[$i]['proctype'] );
				$returnData .= ;
				Controller::pack8int( $roleItem[$i]['data'] );
				$returnData .= ;
				Controller::pack8int( $roleItem[$i]['guid1'] );
				$returnData .= ;
				Controller::pack8int( $roleItem[$i]['guid2'] );
				$returnData .= ;
				Controller::pack8int( $roleItem[$i]['mask'] );
				$returnData .= ;
				++$i;
			}
		}

		Controller::pack8int( $this->pocketReserved1 );
		$returnData .= ;
		Controller::pack8int( $this->pocketReserved2 );
		$returnData .= ;
		Controller::cuint( 3050 );
		$opcode = ;
		strrev( pack( 'I', rand( 1, 9999 ) | 2147483648 ) );
		$id = ;
		strrev( pack( 'I', $this->roleId | 0 ) );
		$roleid2 = ;
		Controller::cuint( strlen( $id . $roleid2 . $returnData ) );
		$length = ;
		$packet = $opcode . $length . $id . $roleid2 . $returnData;
		Controller::sendpacket( 'gamedbd', $packet );
		$data = ;
	}

	function saveEquipment() {
		if ($this->roleInventory == 0) {
			pack( 'H*', '00' );
			$returnData = ;
		}
		else {
			count( $this->roleInventory );
			$count = ;
			strrev( pack( 'C', $count ) );
			$returnData = ;
			$this->roleInventory;
			$roleItem = ;
			$i = 4;

			while ($i < $count) {
				Controller::pack8int( $roleItem[$i]['id'] );
				$returnData .= ;
				Controller::pack8int( $roleItem[$i]['pos'] );
				$returnData .= ;
				Controller::pack8int( $roleItem[$i]['count'] );
				$returnData .= ;
				Controller::pack8int( $roleItem[$i]['maxcount'] );
				$returnData .= ;
				Controller::cuintoctet( strlen( $roleItem[$i]['octet'] ) / 2 );
				$returnData .= ;
				pack( 'H*', $roleItem[$i]['octet'] );
				$returnData .= ;
				Controller::pack8int( $roleItem[$i]['proctype'] );
				$returnData .= ;
				Controller::pack8int( $roleItem[$i]['data'] );
				$returnData .= ;
				Controller::pack8int( $roleItem[$i]['guid1'] );
				$returnData .= ;
				Controller::pack8int( $roleItem[$i]['guid2'] );
				$returnData .= ;
				Controller::pack8int( $roleItem[$i]['mask'] );
				$returnData .= ;
				++$i;
			}
		}

		Controller::cuint( 3016 );
		$opcode = ;
		strrev( pack( 'I', rand( 1, 9999 ) | 2147483648 ) );
		$id = ;
		strrev( pack( 'I', $this->roleId | 0 ) );
		$roleid2 = ;
		Controller::cuint( strlen( $id . $roleid2 . $returnData ) );
		$length = ;
		$packet = $opcode . $length . $id . $roleid2 . $returnData;
		Controller::sendpacket( 'gamedbd', $packet );
		$data = ;
	}

	function saveStorehouse() {
		Controller::pack8int( $this->storeCapacity );
		$returnData = ;
		Controller::pack8int( $this->storeMoney );
		$returnData .= ;

		if ($this->roleStore == 0) {
			pack( 'H*', '00' );
			$returnData .= ;
		}
		else {
			count( $this->roleStore );
			$count = ;
			strrev( pack( 'C', $count ) );
			$returnData .= ;
			$this->roleStore;
			$roleItem = ;
			$i = 4;

			while ($i < $count) {
				Controller::pack8int( $roleItem[$i]['id'] );
				$returnData .= ;
				Controller::pack8int( $roleItem[$i]['pos'] );
				$returnData .= ;
				Controller::pack8int( $roleItem[$i]['count'] );
				$returnData .= ;
				Controller::pack8int( $roleItem[$i]['maxcount'] );
				$returnData .= ;
				Controller::cuintoctet( strlen( $roleItem[$i]['octet'] ) / 2 );
				$returnData .= ;
				pack( 'H*', $roleItem[$i]['octet'] );
				$returnData .= ;
				Controller::pack8int( $roleItem[$i]['proctype'] );
				$returnData .= ;
				Controller::pack8int( $roleItem[$i]['data'] );
				$returnData .= ;
				Controller::pack8int( $roleItem[$i]['guid1'] );
				$returnData .= ;
				Controller::pack8int( $roleItem[$i]['guid2'] );
				$returnData .= ;
				Controller::pack8int( $roleItem[$i]['mask'] );
				$returnData .= ;
				++$i;
			}
		}

		Controller::pack8int( $this->storeSize1 );
		$returnData .= ;
		Controller::pack8int( $this->storeSize2 );
		$returnData .= ;
		Controller::cuint( 3026 );
		$opcode = ;
		strrev( pack( 'I', rand( 1, 9999 ) | 2147483648 ) );
		$id = ;
		strrev( pack( 'I', $this->roleId | 0 ) );
		$roleid2 = ;
		Controller::cuint( strlen( $id . $roleid2 . $returnData ) );
		$length = ;
		$packet = $opcode . $length . $id . $roleid2 . $returnData;
		Controller::sendpacket( 'gamedbd', $packet );
		$data = ;
	}

	function saveTaskdata() {
		Controller::cuintoctet( strlen( $this->taskData ) / 2 );
		$returnData = ;
		pack( 'H*', $this->taskData );
		$returnData .= ;
		Controller::cuintoctet( strlen( $this->taskComplete ) / 2 );
		$returnData .= ;
		pack( 'H*', $this->taskComplete );
		$returnData .= ;
		Controller::cuintoctet( strlen( $this->taskFinishTime ) / 2 );
		$returnData .= ;
		pack( 'H*', $this->taskFinishTime );
		$returnData .= ;

		if ($this->taskInventory == 0) {
			pack( 'H*', '00' );
			$returnData .= ;
		}
		else {
			count( $this->taskInventory );
			$count = ;
			strrev( pack( 'C', $count ) );
			$returnData .= ;
			$this->taskInventory;
			$roleItem = ;
			$i = 4;

			while ($i < $count) {
				Controller::pack8int( $roleItem[$i]['id'] );
				$returnData .= ;
				Controller::pack8int( $roleItem[$i]['pos'] );
				$returnData .= ;
				Controller::pack8int( $roleItem[$i]['count'] );
				$returnData .= ;
				Controller::pack8int( $roleItem[$i]['maxcount'] );
				$returnData .= ;
				Controller::cuintoctet( strlen( $roleItem[$i]['octet'] ) / 2 );
				$returnData .= ;
				pack( 'H*', $roleItem[$i]['octet'] );
				$returnData .= ;
				Controller::pack8int( $roleItem[$i]['proctype'] );
				$returnData .= ;
				Controller::pack8int( $roleItem[$i]['data'] );
				$returnData .= ;
				Controller::pack8int( $roleItem[$i]['guid1'] );
				$returnData .= ;
				Controller::pack8int( $roleItem[$i]['guid2'] );
				$returnData .= ;
				Controller::pack8int( $roleItem[$i]['mask'] );
				$returnData .= ;
				++$i;
			}
		}

		Controller::cuint( 3018 );
		$opcode = ;
		strrev( pack( 'I', rand( 1, 9999 ) | 2147483648 ) );
		$id = ;
		strrev( pack( 'I', $this->roleId | 0 ) );
		$roleid2 = ;
		Controller::cuint( strlen( $id . $roleid2 . $returnData ) );
		$length = ;
		$packet = $opcode . $length . $id . $roleid2 . $returnData;
		Controller::sendpacket( 'gamedbd', $packet );
		$data = ;
	}

	function save() {
		$this->saveBase(  );
		$this->saveStatus(  );
		$this->savePocket(  );
		$this->saveEquipment(  );
		$this->saveStorehouse(  );
		$this->saveTaskdata(  );
	}

	function Role($roleid) {
		Controller::cuint( 3013 );
		$opcode = ;
		strrev( pack( 'I', rand( 1, 9999 ) | 2147483648 ) );
		$id = ;
		strrev( pack( 'I', $roleid | 0 ) );
		Controller::cuint( strlen( $id . $roleid ) );
		$length = ;
		$packet = $opcode . $length . $id . $roleid;
		Controller::sendpacket( 'gamedbd', $packet );
		$data = ;
		$this->parseBase( $data );
		Controller::cuint( 3015 );
		$opcode = ;
		strrev( pack( 'I', rand( 1, 9999 ) | 2147483648 ) );
		$id = ;
		Controller::cuint( strlen( $id . $roleid ) );
		$length = ;
		$packet = $opcode . $length . $id . $roleid;
		Controller::sendpacket( 'gamedbd', $packet );
		$data = ;
		$this->parseStatus( $data );
		Controller::cuint( 3051 );
		$opcode = ;
		strrev( pack( 'I', rand( 1, 9999 ) | 2147483648 ) );
		$id = ;
		Controller::cuint( strlen( $id . $roleid ) );
		$length = ;
		$packet = $opcode . $length . $id . $roleid;
		Controller::sendpacket( 'gamedbd', $packet );
		$data = ;
		$this->parsePocket( $data );
		Controller::cuint( 3017 );
		$opcode = ;
		strrev( pack( 'I', rand( 1, 9999 ) | 2147483648 ) );
		$id = ;
		Controller::cuint( strlen( $id . $roleid ) );
		$length = ;
		$packet = $opcode . $length . $id . $roleid;
		Controller::sendpacket( 'gamedbd', $packet );
		$data = ;
		$this->parseEquipment( $data );
		Controller::cuint( 3027 );
		$opcode = ;
		strrev( pack( 'I', rand( 1, 9999 ) | 2147483648 ) );
		$id = ;
		Controller::cuint( strlen( $id . $roleid ) );
		$length = ;
		$packet = $opcode . $length . $id . $roleid;
		Controller::sendpacket( 'gamedbd', $packet );
		$data = ;
		$this->parseStorehouse( $data );
		Controller::cuint( 3019 );
		$opcode = ;
		strrev( pack( 'I', rand( 1, 9999 ) | 2147483648 ) );
		$id = ;
		Controller::cuint( strlen( $id . $roleid ) );
		$length = ;
		$packet = $opcode . $length . $id . $roleid;
		Controller::sendpacket( 'gamedbd', $packet );
		$data = $roleid = ;
		$this->parseTaskdata( $data );
	}
}

?>

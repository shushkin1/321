<?php

class DomainPw126 {
	var $domain = null;

	function __construct() {
		if (isset( Yii::app(  )->params->license_key )) {
			str_replace( '-', '', Yii::app(  )->params->license_key );
			$license_key = ;
			hash( 'sha256', base64_encode( $_SERVER['SERVER_ADDR'] ) . 'perfect world' . 'fucking cheaters' );
			$checkLicense1 = ;

			if ($license_key != $checkLicense1) {
				exit( 'wrong license key' );
			}
		}
		else {
			exit( 'wrong license key' );
		}

		$this->Domain(  );
	}

	function parse($data) {
		substr( $data, 4 );
		$data = ;
		$length = 2 + hexdec( substr( $data, 0, 2 ) ) * 2;
		$length2 = 4 + 2 * ( hexdec( substr( $data, 0, 4 ) ) - 32768 );

		if ($length == strlen( $data )) {
			substr( $data, 2 );
			$data = ;
		}
		else {
			if ($length2 == strlen( $data )) {
				substr( $data, 4 );
				$data = ;
			}
			else {
				substr( $data, 8 );
				$data = ;
			}
		}

		substr( $data, 12 );
		$data = ;
		hexdec( substr( $data, 0, 2 ) );
		$count = ;
		substr( $data, 2 );
		$data = ;

		if (0 < $count) {
			$i = 4;

			while ($i < $count) {
				$domain[$i]['id'] = hexdec( substr( $data, 0, 4 ) );
				substr( $data, 4 );
				$data = ;
				$domain[$i]['level'] = hexdec( substr( $data, 0, 4 ) );
				substr( $data, 4 );
				$data = ;
				$domain[$i]['owner'] = hexdec( substr( $data, 0, 8 ) );
				substr( $data, 8 );
				$data = ;

				if (!empty( $domain[$i]['owner'] )) {
					FactioninfoPw126;
					new ( $domain[$i]['owner'] );
					$factionInfo = ;
					$domain[$i]['owner_name'] = $factionInfo->factionName;
				}

				$domain[$i]['occupy_time'] = hexdec( substr( $data, 0, 8 ) );
				substr( $data, 8 );
				$data = ;
				$domain[$i]['attacker'] = hexdec( substr( $data, 0, 8 ) );
				substr( $data, 8 );
				$data = ;

				if (!empty( $domain[$i]['attacker'] )) {
					FactioninfoPw126;
					new ( $domain[$i]['attacker'] );
					$factionInfo = ;
					$domain[$i]['attacker_name'] = $factionInfo->factionName;
				}

				$domain[$i]['deposit'] = hexdec( substr( $data, 0, 8 ) );
				substr( $data, 8 );
				$data = ;
				$domain[$i]['cutoff_time'] = hexdec( substr( $data, 0, 8 ) );
				substr( $data, 8 );
				$data = ;
				$domain[$i]['battle_time'] = hexdec( substr( $data, 0, 8 ) );
				substr( $data, 8 );
				$data = ;
				$domain[$i]['bonus_time'] = hexdec( substr( $data, 0, 8 ) );
				substr( $data, 8 );
				$data = ;
				$domain[$i]['color'] = hexdec( substr( $data, 0, 8 ) );
				substr( $data, 8 );
				$data = ;
				$domain[$i]['status'] = hexdec( substr( $data, 0, 8 ) );
				substr( $data, 8 );
				$data = ;
				$domain[$i]['timeout'] = hexdec( substr( $data, 0, 8 ) );
				substr( $data, 8 );
				$data = ;
				$domain[$i]['max_bonus'] = hexdec( substr( $data, 0, 8 ) );
				substr( $data, 8 );
				$data = ;
				$domain[$i]['date'] = hexdec( substr( $data, 0, 8 ) );
				substr( $data, 8 );
				$data = ;
				$lengthBids = hexdec( substr( $data, 0, 2 ) ) * 2;
				substr( $data, 2 );
				$data = ;
				$domain[$i]['bids'] = substr( $data, 0, $lengthBids );
				substr( $data, $lengthBids );
				$data = ;
				$domain[$i]['unk'] = substr( $data, 0, 6 );
				substr( $data, 6 );
				$data = ;
				++$i;
			}

			$this->domain = $domain;
		}

	}

	function Domain() {
		Controller::cuint( 863 );
		strrev( pack( 'I', rand( 1, 9999 ) | 2147483648 ) );
		$id = ;
		strrev( pack( 'I', 1 | 0 ) );
		$domain = ;
		Controller::cuint( strlen( $id . $domain ) );
		$length = ;
		$packet = $opcode . $length . $id . $domain;
		Controller::sendpacket( 'gamedbd', $packet );
		$data = $opcode = ;
		$this->parse( $data );
	}
}

?>

<?php
class FwModule extends CWebModule
{
    public function init()
    {
        $this->setImport(array(
            'fw.models.*',
            'fw.components.*',
        ));
    }

    public function beforeControllerAction($controller, $action)
    {
        if (parent::beforeControllerAction($controller, $action)) {
            return true;
        } else
            return false;
    }
}
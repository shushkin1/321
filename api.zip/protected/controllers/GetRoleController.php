<?php
class GetRoleController extends Controller
{
    public $error = 1;
    public $status = 0;
    public $data = '';

    public function actions()
    {
        return array(
            'quote' => array(
                'class' => 'CWebServiceAction',
            ),
        );
    }

    /**
     * @param int roleid
     * @return array результат
     * @soap
     */
    public function getRole($roleid)
    {
        if (isset($roleid)) {
            $role = new Role($roleid);

            $this->data = serialize($role);
            $this->error = '0';
            $this->status = '1';
        }


        return array(
            'error' => $this->error,
            'status' => $this->status,
            'data' => $this->data,
        );
    }

    /**
     * @param mixed data
     * @return array результат
     * @soap
     */
    public function setRole($data) // soap не пашет, курлом шлем :)
    {
        $roleid = $data['roleId'];

        if (isset($roleid)) {
            $data = unserialize($data['data']);
            $role = new Role($roleid);
            $role = $data;
            $role->save();

            $this->error = '0';
            $this->status = '1';
        }


        return array(
            'error' => $this->error,
            'status' => $this->status,
            'data' => $this->data,
        );
    }

    public function actionCurl()
    {
        if (isset($_GET['data'])) {
            $data = unserialize($_GET['data']);
        } elseif (isset($_POST['data'])) {
            $data = json_decode($_POST['data'], true);
        }

        if (isset($data) AND $data['what'] == 'get') {
            $result = $this->getRole($data['roleId']);
            echo serialize($result);
        } else {
            $result = $this->setRole($data);
            echo serialize($result);
        }
    }
}
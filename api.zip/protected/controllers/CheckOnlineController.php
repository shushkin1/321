<?php
class CheckOnlineController extends Controller
{
    public $error = 1;
    public $status = 0;
    public $data = '';

    public function actions()
    {
        return array(
            'quote' => array(
                'class' => 'CWebServiceAction',
            ),
        );
    }

    /**
     * @param int id
     * @return array результат
     * @soap
     */
    public function checkOnline($id)
    {
        $point = Point::model()->findByAttributes(array('uid' => $id));

        if (isset($point->zoneid) AND !empty($point->zoneid)) {
            $this->error = 0;
            $this->status = 1;
            $this->data = array(
                'id' => $id,
            );
        } else {
            $this->error = 2;
            $this->status = 0;
        }

        return array(
            'error' => $this->error,
            'status' => $this->status,
            'data' => $this->data,
        );
    }

    public function actionCurl()
    {
        $data = unserialize($_GET['data']);
        $result = $this->checkOnline($data['id']);
        echo serialize($result);
    }
}
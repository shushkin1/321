<?php
class GetGuildtopController extends Controller
{
    public $error = 1;
    public $status = 0;
    public $data = '';

    public function actions()
    {
        return array(
            'quote' => array(
                'class' => 'CWebServiceAction',
            ),
        );
    }

    /**
     * @return array result
     * @soap
     */
    public function getGuildtop()
    {
        $domain = new Domain();
        $this->data = $domain->domain;
        $this->status = '1';
        $this->error = '0';

        return array(
            'error' => $this->error,
            'status' => $this->status,
            'data' => $this->data,
        );
    }

    public function actionCurl()
    {
        $result = $this->getGuildtop();
        echo serialize($result);
    }
}
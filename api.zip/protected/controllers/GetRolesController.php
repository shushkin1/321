<?php
class GetRolesController extends Controller
{
    public $error = 1;
    public $status = 0;
    public $data = '';

    public function actions()
    {
        return array(
            'quote' => array(
                'class' => 'CWebServiceAction',
            ),
        );
    }

    /**
     * @param string name
     * @return array result
     * @soap
     */
    public function getRoles($name)
    {
        $id = Users::model()->findByAttributes(array('name' => $name));
        if (isset($id->ID) AND !empty($id->ID)) {
            $roles = new Roles($id->ID);
            $roles = $roles->roles;
            for ($i = 0, $count = count($roles); $i < $count; $i++) {
                $roleId = $roles[$i]['roleid'];
                $role = new Role($roleId);
                $roles[$i]['class'] = $role->roleClass;
                $roles[$i]['level'] = $role->level;
            }

            if (isset($roles['0']['roleid']) AND !empty($roles['0']['roleid'])) {
                $this->data = $roles;
                $this->status = '1';
                $this->error = '0';
            } else {
                $this->error = '4';
            }
        }

        return array(
            'error' => $this->error,
            'status' => $this->status,
            'data' => $this->data,
        );
    }

    /**
     * @param string login or name
     * @param int userid
     * @param int roleid
     * @return array result
     * @soap
     */
    public function listRoles($login_or_name, $userid, $roleid)
    {
        if (!empty($userid)) {
            $userid = Users::model()->findByPk($userid);
            if (isset($userid)) {
                $userid = $userid->ID;
            } else {
                $this->error = '3'; // not exists userid
            }
        } elseif (!empty($login_or_name)) {
            $userid = Users::model()->findByAttributes(array('name' => $login_or_name));
            if (!isset($userid)) {
                $rolename = new Rolename($login_or_name);
                if (!empty($rolename->roleid)) {
                    $role = new Role((int)$rolename->roleid);
                    $userid = $role->userid;
                } else {
                    $this->error = '2'; // not exists login or rolename
                }
            } else {
                $userid = $userid->ID;
            }
        } elseif (!empty($roleid)) {
            @$role = new Role($roleid);
            if(!empty($role->userid)){
                $userid = $role->userid;
            } else {
                $this->error = '5'; // not exists roleid
            }
        }

        if (!empty($userid)) {
            $roles = new Roles($userid);
            $roles = $roles->roles;
            for ($i = 0, $count = count($roles); $i < $count; $i++) {
                $roleId = $roles[$i]['roleid'];
                $role = new Role($roleId);
                $roles[$i]['class'] = $role->roleClass;
                $roles[$i]['level'] = $role->level;
            }

            if (isset($roles['0']['roleid']) AND !empty($roles['0']['roleid'])) {
                $this->data = $roles;
                $this->status = '1';
                $this->error = '0';
            } else {
                $this->error = '4';
            }
        }

        return array(
            'error' => $this->error,
            'status' => $this->status,
            'data' => $this->data,
        );
    }

    public function actionCurl()
    {
        $data = unserialize($_GET['data']);
        if (isset($data['name'])) {
            $result = $this->getRoles($data['name']);
        } else {
            $result = $this->listRoles($data['login_or_name'], $data['userid'], $data['roleid']);
        }

        echo serialize($result);
    }
}
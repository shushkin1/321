<?php
class RoleFactionController extends Controller
{
    public $error = 1;
    public $status = 0;
    public $data = '';

    public function actions()
    {
        return array(
            'quote' => array(
                'class' => 'CWebServiceAction',
            ),
        );
    }

    /**
     * @param int roleid
     * @return array результат
     * @soap
     */
    public function roleFaction($roleid)
    {
        if (isset($roleid)) {
            $rolefaction = new Rolefaction($roleid);
            if (isset($rolefaction->roleId) AND $rolefaction->roleId != '0') {
                $factioninfo = new Factioninfo($rolefaction->factionId);

                $this->data = array(
                    'factionId' => $rolefaction->factionId,
                    'post' => $rolefaction->post,
                    'factionName' => $factioninfo->factionName,
                );
                $this->status = '1';
                $this->error = '0';
            } else {
                $this->error = '5';
            }
        }

        return array(
            'error' => $this->error,
            'status' => $this->status,
            'data' => $this->data,
        );
    }

    public function actionCurl()
    {
        $data = unserialize($_GET['data']);
        $result = $this->roleFaction($data['roleid']);
        echo serialize($result);
    }
}
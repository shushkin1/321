<?php
class SetLevelController extends Controller
{
    public $error = 1;
    public $status = 0;
    public $data = '';

    public function actions()
    {
        return array(
            'quote' => array(
                'class' => 'CWebServiceAction',
            ),
        );
    }

    /**
     * @param int roleid
     * @param int new level
     * @return array result
     * @soap
     */
    public function setLevel($id, $level)
    {
        if (isset($id) AND isset($level)) {
            $role = new Role($id);

            if ($level > $role->level) {
                $calculate = Calculate::levelUp($role->roleClass, $level, $role->stamina, $role->intelligence);
                $role->points = $role->points + (5 * ($level - $role->level));
                $role->level = $level;
                $role->hp = $calculate['hp'];
                $role->mp = $calculate['mp'];
                $role->minPhysAtt = $calculate['minPhys'];
                $role->maxPhysAtt = $calculate['maxPhys'];
                $role->minMagAtt = $calculate['minMag'];
                $role->maxMagAtt = $calculate['maxMag'];

                $controller = Yii::app()->createController('checkOnline/default');
                $result = $controller[0]->checkOnline($role->userid);
                if ($result['error'] == '2') {
                    $role->save();

                    $this->error = '0';
                    $this->status = '1';
                } else {
                    $this->error = '3'; // role online
                    $this->status = '0';
                }

            } else {
                $this->error = '2'; // new level is too low
                $this->status = '0';
            }
        }

        return array(
            'error' => $this->error,
            'status' => $this->status,
            'data' => $this->data,
        );
    }

    public function actionCurl()
    {
        $data = unserialize($_GET['data']);
        $result = $this->setLevel($data['id'], $data['level']);
        echo serialize($result);
    }
}
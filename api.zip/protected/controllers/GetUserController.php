<?php
class GetUserController extends Controller
{
    public $error = 1;
    public $status = 0;
    public $data = '';

    public function actions()
    {
        return array(
            'quote' => array(
                'class' => 'CWebServiceAction',
            ),
        );
    }

    /**
     * @param string name
     * @return array
     * @soap
     */
    public function getUser($name)
    {
        $user = Users::model()->findByAttributes(array('name' => $name));
        if (isset($user['ID'])) {
            $this->error = 0;
            $this->status = 1;
            $this->data = array(
                'id' => $user->ID,
                'name' => $user->name,
                'email' => $user->email,
            );

        }

        return array(
            'error' => $this->error,
            'status' => $this->status,
            'data' => $this->data,
        );
    }

    public function actionCurl()
    {
        $data = unserialize($_GET['data']);
        $result = $this->getUser($data['name']);
        echo serialize($result);
    }
}
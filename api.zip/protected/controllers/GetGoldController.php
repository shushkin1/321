<?php
class GetGoldController extends Controller
{
    public $error = 1;
    public $status = 0;
    public $data = '';

    public function actions()
    {
        return array(
            'quote' => array(
                'class' => 'CWebServiceAction',
            ),
        );
    }

    /**
     * @param int userid
     * @param int gold
     * @return array result
     * @soap
     */
    public function getGold($id, $gold)
    {
        if (isset($id) AND isset($gold)) {
            $gold = $gold * 100;
            $connection = Yii::app()->db;
            $sql = "call usecash(" . $id . "," . Yii::app()->params->zoneid . ",0," . Yii::app()->params->aid . ",0," . $gold . ",1,@error)";
            $command = $connection->createCommand($sql);
            $success = $command->query();

            $this->error = '0';
            $this->status = '1';
        }

        return array(
            'error' => $this->error,
            'status' => $this->status,
            'data' => $this->data,
        );
    }

    public function actionCurl()
    {
        $data = unserialize($_GET['data']);
        $result = $this->getGold($data['id'], $data['gold']);
        echo serialize($result);
    }
}
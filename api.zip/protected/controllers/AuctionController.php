<?php
class AuctionController extends Controller
{
    public $error = 1;
    public $status = 0;
    public $data = '';

    public function actions()
    {
        return array(
            'quote' => array(
                'class' => 'CWebServiceAction',
            ),
        );
    }

    /**
     * @param int roleid
     * @return array result
     * @soap
     */
    public function getInventory($roleid)
    {
        if (isset($roleid)) {
            $role = new Role($roleid);

            $this->data = $role->rolePocket;
            $this->error = '0';
            $this->status = '1';
        }


        return array(
            'error' => $this->error,
            'status' => $this->status,
            'data' => $this->data,
        );
    }

    /**
     * @param int roleid
     * @param int position
     * @return array result
     * @soap
     */
    public function ejectItem($roleid, $position)
    {
        if (isset($roleid)) {
            $role = new Role($roleid);

            $controller = Yii::app()->createController('checkOnline/default');
            $result = $controller[0]->checkOnline($role->userid);

            if ($result['error'] == '2') {
                $item = $role->rolePocket[$position];
                array_splice($role->rolePocket, $position, 1);
                $role->save();

                $this->data = $item;
                $this->error = '0';
                $this->status = '1';
            } else {
                $this->error = '3'; // role online
                $this->status = '0';
            }
        }


        return array(
            'error' => $this->error,
            'status' => $this->status,
            'data' => $this->data,
        );
    }

    public function actionCurl()
    {
        $data = unserialize($_GET['data']);
        if (!isset($data['position'])) {
            $result = $this->getInventory($data['id']);
        } else {
            $result = $this->ejectItem($data['id'], $data['position']);
        }

        echo serialize($result);
    }
}
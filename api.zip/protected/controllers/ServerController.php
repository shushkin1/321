<?php
class ServerController extends Controller
{
    public $error = 1;
    public $status = 0;
    public $data = '';

    public function actions()
    {
        return array(
            'quote' => array(
                'class' => 'CWebServiceAction',
            ),
        );
    }

    /**
     * @return array
     * @soap
     */
    public function getOnline()
    {
        $online = Point::model()->countByAttributes(array('zoneid'=>Yii::app()->params->zoneid));
        $this->data = $online;
        $this->status = '1';
        $this->error = '0';

        return array(
            'error' => $this->error,
            'status' => $this->status,
            'data' => $this->data,
        );
    }

    public function actionCurl()
    {
        $data = unserialize($_GET['data']);
        if($data['what']=='online'){
            $result = $this->getOnline();
        }
        echo serialize($result);
    }
}
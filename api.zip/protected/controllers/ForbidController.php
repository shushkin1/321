<?php
class ForbidController extends Controller
{
    public $error = 1;
    public $status = 0;
    public $data = '';

    public function actions()
    {
        return array(
            'quote' => array(
                'class' => 'CWebServiceAction',
            ),
        );
    }

    /**
     * @param int userid
     * @param int roleid
     * @param string name
     * @param int time
     * @param string reason
     * @param int gm id
     * @param int type
     * @return array result
     * @soap
     */
    public function userForbid($userid, $roleid, $name, $time, $reason, $gm, $type)
    {
        if (isset($time) AND isset($reason)) {
            if (isset($roleid) AND !empty($roleid)) {
                $role = new Role($roleid);
                $userid = $role->userid;
            } elseif (isset($name) AND !empty($name)) {
                $roleid = new Rolename($name);
                if (isset($roleid->roleid)) {
                    $role = new Role($roleid->roleid);
                    $userid = $role->userid;
                } else {
                    $this->error = '5'; // name not exists
                }
            } else {

            }

            if (isset($userid) AND !empty($userid)) {
                $userforbid = new Userforbid;
                $userforbid->operation = $type;
                $userforbid->gm = $gm;
                $userforbid->source = '0';
                $userforbid->userid = $userid;
                $userforbid->time = $time;
                $userforbid->reason = $reason;
                $userforbid->save();

                $this->status = '1';
                $this->error = '0';
                $this->data = $userid;
            } else {
                $this->error = '6'; // all params empty
            }
        }

        return array(
            'error' => $this->error,
            'status' => $this->status,
            'data' => $this->data,
        );
    }

    public function actionCurl()
    {
        $data = unserialize($_GET['data']);
        $result = $this->userForbid($data['userid'], $data['roleid'], $data['name'], $data['time'], $data['reason'], $data['gm'], $data['type']);
        echo serialize($result);
    }
}
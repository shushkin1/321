<?php
class GetRoleidController extends Controller
{
    public $error = 1;
    public $status = 0;
    public $data = '';

    public function actions()
    {
        return array(
            'quote' => array(
                'class' => 'CWebServiceAction',
            ),
        );
    }

    /**
     * @param string name
     * @return array результат
     * @soap
     */
    public function getRoleid($name)
    {
        if (isset($name)) {
            $roleid = new Rolename($name);
            if (isset($roleid->roleid) AND !empty($roleid->roleid)) {
                $this->data = array('roleid' => $roleid->roleid);
                $this->status = '1';
                $this->error = '0';
            } else {
                $this->error = '5';
            }
        }

        return array(
            'error' => $this->error,
            'status' => $this->status,
            'data' => $this->data,
        );
    }

    public function actionCurl()
    {
        $data = unserialize($_GET['data']);
        $result = $this->getRoleid($data['name']);
        echo serialize($result);
    }
}
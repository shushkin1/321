<?php
class GetUsertopController extends Controller
{
    public $error = 1;
    public $status = 0;
    public $data = '';

    public function actions()
    {
        return array(
            'quote' => array(
                'class' => 'CWebServiceAction',
            ),
        );
    }

    /**
     * @param string desc
     * @return array result
     * @soap
     */
    public function getUsertop($desc)
    {
        $usertop = Usertop::model()->findAll(array('limit' => '100', 'order' => $desc . ' DESC'));
        if (isset($usertop)) {
            for ($i = 0, $count = count($usertop); $i < $count; $i++) {
                $top[$i]['id'] = $usertop[$i]->id;
                $top[$i]['name'] = $usertop[$i]->name;
                $top[$i]['class'] = $usertop[$i]->class;
                $top[$i]['gender'] = $usertop[$i]->gender;
                $top[$i]['create'] = $usertop[$i]->create;
                $top[$i]['level'] = $usertop[$i]->level;
                $top[$i]['cultivation'] = $usertop[$i]->cultivation;
                $top[$i]['hp'] = $usertop[$i]->hp;
                $top[$i]['mp'] = $usertop[$i]->mp;
                $top[$i]['pariah'] = $usertop[$i]->pariah;
                $top[$i]['reputation'] = $usertop[$i]->reputation;
                $top[$i]['online'] = $usertop[$i]->online;
                $top[$i]['feat'] = $usertop[$i]->feat;
                $top[$i]['kills'] = $usertop[$i]->kills;
            }
            if(isset($top['0']['id']) AND !empty($top['0']['id'])){
                $this->data = $top;
                $this->status = '1';
                $this->error = '0';
            }
        }

        return array(
            'error' => $this->error,
            'status' => $this->status,
            'data' => $this->data,
        );
    }

    public function actionCurl()
    {
        $data = unserialize($_GET['data']);
        $result = $this->getUsertop($data['desc']);
        echo serialize($result);
    }
}
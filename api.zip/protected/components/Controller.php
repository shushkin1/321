<?php

class Controller extends RController
{
	var $layout = '//layouts/column1';
	var $menu = array();
	var $breadcrumbs = array();
	
	function __construct()
	{
/*
		if (isset(Yii::app( )->params->license_key))
		{
			$license_key = str_replace( '-', '', Yii::app( )->params->license_key);
			$checkLicense1 = hash('sha256', base64_encode($_SERVER['SERVER_ADDR']).'perfect world'.'fucking cheaters');
			$checkLicense2 = hash('sha256', base64_encode($_SERVER['SERVER_ADDR']).'forsaken world'.'fucking cheaters');
			$checkLicense3 = hash('sha256', base64_encode($_SERVER['SERVER_ADDR']).'jade dynasty'.'fucking cheaters');
			if ((($license_key != $checkLicense1 && $license_key != $checkLicense2) && $license_key != $checkLicense3)) 
			{
				exit('wrong license key');
				return null;
			}
		}
		else
		{
			exit('wrong license key');
		}
*/
	}
	
	function cuint($data)
	{
		if ($data < 64) {
			return strrev(pack('C', $data));
		}
		if ($data < 16384) {
			return strrev(pack('S', $data | 32768));
		}
		if ($data < 536870912) {
			return strrev(pack( 'I', $data | 3221225472));
		}
		return strrev(pack('c', 0 - 32).pack('I', $data));
	}
	
	function sendPacket($where, $data, $wait_reply = true)
	{
		if ($where == 'gamedbd')
		{
			$port = Yii::app( )->params->gamedbd;
		}
		else {
			$port = Yii::app( )->params->gdeliveryd;
		}
		
		$socket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
		$bind = socket_connect($socket, '127.0.0.1', $port);
		$query = socket_send($socket, $data, 524288, 0);
		
		if ($wait_reply == true)
		{
			$reply = socket_recv($socket, $answer, 524288, 0);
			$packet = $answer;
			$finish = '0';
			
			while ($finish == '0')
			{
				$checkReply = substr($packet, 2);
				$length = 1 + hexdec(bin2hex(substr($checkReply, 0, 1)));
				$length2 = 2 + (hexdec(bin2hex(substr($checkReply, 0, 2))) - 32768);
				$length3 = 4 + (hexdec(bin2hex(substr($checkReply, 0, 4))) - 3221225472);
				
				if ($length == strlen($checkReply))
				{
					$finish = '1';
					continue;
				}
				
				
				if ($length2 == strlen($checkReply))
				{
					$finish = '1';
					continue;
				}
				
				
				if ($length3 == strlen($checkReply))
				{
					$finish = '1';
					continue;
				}
				
				$reply = socket_recv($socket, $answer, 524288, 0);
				$packet .= $answer;
			}
			
			$packet = bin2hex($packet);
		}
		else 
		{
			$packet = '';
		}
		
		socket_close($socket);
		return $packet;
	}
	
	function sendPacketFw($where, $data)
	{
		if ($where == 'gamedbd')
		{
			$port = Yii::app( )->params->gamedbd;
		}
		else
		{
			$port = Yii::app( )->params->gdeliveryd;
		}
		
		$socket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
		$bind = socket_connect($socket, '127.0.0.1', $port);
		$reply = socket_recv($socket, $answer, 524288, 0);
		$query = socket_send($socket, $data, 524288, 0);
		$reply = socket_recv($socket, $answer, 524288, 0);
		$packet = $answer;
		$finish = '0';
		
		while ($finish == '0') 
		{
			$checkReply = substr($packet, 2);
			$length = 1 + hexdec(bin2hex(substr($checkReply, 0, 1)));
			$length2 = 2 + (hexdec(bin2hex(substr($checkReply, 0, 2))) - 32768);
			$length3 = 4 + (hexdec(bin2hex(substr($checkReply, 0, 4))) - 3221225472);
			
			if ($length == strlen($checkReply))
			{
				$finish = '1';
				continue;
			}
			
			
			if ($length2 == strlen($checkReply))
			{
				$finish = '1';
				continue;
			}
			
			
			if ($length3 == strlen($checkReply))
			{
				$finish = '1';
				continue;
			}
			
			$reply = socket_recv($socket, $answer, 524288, 0);
			$packet .= $answer;
		}
		
		socket_close($socket);
		$packet = bin2hex($packet);
		return $packet;
	}
	
	function suckHexToInt($value)
	{
		$value = str_split($value, 2);
		$value = $value['3'].$value['2'].$value['1'].$value['0'];
		$value = hexdec($value);
		return $value;
	}
	
	function cuintOctet($data)
	{
		if ($data < 128)
		{
			return strrev(pack('C', $data));
		}
		
		return strrev(pack('S', $data | 32768));
	}
	
	function suckHexdec($hex)
	{
		if (strlen( $hex ) == '4') 
		{
			$hex = str_split($hex, 2);
			$hex = $hex['1'].$hex['0'];
		}
		else 
		{
			$hex = str_split($hex, 2);
			$hex = $hex['3'].$hex['2'].$hex['1'].$hex['0'];
		}
		
		$hex = hexdec($hex);
		return $hex;
	}
	
	function pack8int($data)
	{
		return strrev(pack('I', $data | 0));
	}
	
	function packShort($data)
	{
		return strrev(pack( 'S', $data | 0 ));
	}
	
	function hexToStr($hex)
	{
		$string = '';
		$i = 4;
		
		while ($i < strlen( $hex ) - 1) 
		{
			$string .= chr(hexdec($hex[$i].$hex[$i + 1]));
			$i += 6;
		}
		
		return $string;
	}
	
	function intToSuckHex($value)
	{
		$value = bin2hex(strrev(pack('I', $value | 0)));
		$value = str_split($value, 2);
		$value = $value['3'].$value['2'].$value['1'].$value['0'];
		return $value;
	}
	
	function hexTo32Float($strHex)
	{
		$v = hexdec( $strHex );
		$x = ($v & (1 << 23) - 1) + (1 << 23) * ($v >> 31 | 1);
		$exp = ($v >> 23 & 255) - 127;
		return $x * pow(2, $exp - 23);
	}
}

?>

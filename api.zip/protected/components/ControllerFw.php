<?php
class ControllerFw extends RController
{
    public function packLong($data)
    {
        $left = 0xffffffff00000000;
        $right = 0x00000000ffffffff;
        $l = ($data & $left) >>32;
        $r = $data & $right;
        $good = pack('NN', $l, $r);
        return $good;
    }

    public function unpackLong($data)
    {
        $data = pack("H*", $data);
        $set = unpack('N2', $data);
        $original = $set[1] << 32 | $set[2];
        return $original;
    }
}
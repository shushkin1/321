<?php
return array (
  'template' => 'default',
  'tablePrefix' => '',
  'modelPath' => 'application.models3',
  'baseClass' => 'CActiveRecord',
  'buildRelations' => '1',
);

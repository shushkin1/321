<?php
/*
 * author gibat
 * api version 2.10 alpha
 */
return array(
	'basePath'=>dirname(__FILE__).DIRECTORY_SEPARATOR.'..',
	'name'=>'gCP v.2',

	'preload'=>array('log'),

	'import'=>array(
		'application.models.*',
		'application.components.*',
		'application.modules.rights.*',
		'application.modules.rights.models.*',
		'application.modules.rights.components.*',
        'application.modules.fw.*',
        'application.modules.fw.models.*',
        'application.modules.fw.components.*',
        'application.modules.pw126.*',
        'application.modules.pw126.models.*',
        'application.modules.pw126.components.*',
	),

	'modules'=>array(
        'user',
        'rights',
        /*'gii'=>array(
            'class'=>'system.gii.GiiModule',
            'password'=>'1',
            'ipFilters'=>array('127.0.0.1','::1'),
        ),*/
        'fw',
        'jd',
        'pw126',
	),

	'components'=>array(
		'urlManager'=>array(
			'urlFormat'=>'path',
			'showScriptName'=>false,
			'rules'=>array(
                '<module:\w+>/<controller:\w+>/<id:\d+>'=>'<module>/<controller>/view',
                '<module:\w+>/<controller:\w+>/<action:\w+>/<id:\d+>'=>'<module>/<controller>/<action>',
                '<module:\w+>/<controller:\w+>/<action:\w+>'=>'<module>/<controller>/<action>',

				'<controller:\w+>/<id:\d+>'=>'<controller>/view',
				'<controller:\w+>/<action:\w+>/<id:\d+>'=>'<controller>/<action>',
				'<controller:\w+>/<action:\w+>'=>'<controller>/<action>',
				'<what:\w+>/*'=>'<what>',
			),
		),
		'db'=>array(
			'connectionString' => 'mysql:host=localhost;dbname=pw',
			'schemaCachingDuration'=>3600,
			'emulatePrepare' => true,
			'username' => 'root',
			'password' => '',
			'charset' => 'utf8',
			'tablePrefix' => '',
			//'enableProfiling'=>true,
		),
		'cache'=>array(
      		'class'=>'CFileCache',
    	),
    	
		'errorHandler'=>array(
      		'errorAction'=>'site/error',
    	),
		/*'log'=>array(
			'class'=>'CLogRouter',
			'routes'=>array(
				array(
					'class'=>'CFileLogRoute',
					'levels'=>'error, warning',
				),
				array(
					'class'=>'CWebLogRoute',
				),
			),
		),*/
	),
	
	'params'=>array(
        'license_key'=>'2e2b2d455c809a94-dd4e0ad7f5b36c95-de07480ec3d80cdd-717a2ce536e2967f',
		
        'version'=>'1.4.6', // pw: 1.4.4 or 1.4.5 or 1.4.5.69 or 1.4.6, fw: nf or was
        'gamedbd'=>29400,
        'gdeliveryd'=>29100,
        'addgold'=>'0', // 1 - on, 0 - off
        'gold'=>'100000',
        'zoneid'=>'1',
        'aid'=>'1',
        'mail_title'=>'Донат',
        'mail_text'=>'Спасибо за вашу покупку на сервере PWServer',
		
        // teleport settings
        'worldtag'=>'1',
        'posx'=>'1270',
        'posy'=>'253',
        'posz'=>'1034',
	),
);
